#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
数据预处理模块
负责数据的预处理工作，包括空格清理、全角半角转换等
"""

import logging
import re
from typing import Dict, List, Any, Tuple

class DataPreprocessor:
    """数据预处理器"""
    
    def __init__(self):
        """初始化"""
        self.logger = logging.getLogger(__name__)
        # 从配置文件导入配置
        from config import Config
        # 空值占位符列表
        self.null_placeholders = Config.NULL_PLACEHOLDERS
        # 人民币标识符
        self.rmb_identifiers = Config.RMB_IDENTIFIERS
    
    def process(self, sheets_data: Dict[str, Dict[str, Any]]) -> Dict[str, Dict[str, Any]]:
        """处理所有sheet的数据
        
        Args:
            sheets_data: 原始数据
            
        Returns:
            Dict: 处理后的数据
        """
        processed_data = {}
        
        for sheet_name, sheet_content in sheets_data.items():
            self.logger.info(f"预处理sheet: {sheet_name}")
            
            # 处理表头
            headers = self.process_headers(sheet_content['headers'])
            
            # 处理数据（使用并行处理）
            import concurrent.futures
            import psutil
            
            rows = sheet_content['data']
            processed_rows = []
            
            # 根据CPU核心数确定并行度
            cpu_count = psutil.cpu_count()
            max_workers = min(cpu_count, 4)  # 最多使用4个核心
            
            if len(rows) > 100:
                # 对于大量数据使用并行处理
                self.logger.info(f"使用 {max_workers} 个工作线程并行处理数据")
                
                with concurrent.futures.ThreadPoolExecutor(max_workers=max_workers) as executor:
                    # 提交所有行到线程池
                    future_to_row = {executor.submit(self.process_row, row, headers): i for i, row in enumerate(rows)}
                    
                    # 处理结果
                    for future in concurrent.futures.as_completed(future_to_row):
                        try:
                            processed_row = future.result()
                            processed_rows.append(processed_row)
                        except Exception as e:
                            self.logger.error(f"处理行时发生错误: {str(e)}")
            else:
                # 对于少量数据使用串行处理
                for i, row in enumerate(rows):
                    processed_row = self.process_row(row, headers)
                    processed_rows.append(processed_row)
            
            processed_data[sheet_name] = {
                'headers': headers,
                'data': processed_rows
            }
            
            self.logger.info(f"Sheet '{sheet_name}' 预处理完成")
        
        return processed_data
    
    def process_headers(self, headers: List[str]) -> List[str]:
        """处理表头
        
        Args:
            headers: 原始表头
            
        Returns:
            List: 处理后的表头
        """
        processed_headers = []
        for header in headers:
            if header is None:
                processed_headers.append('')
            else:
                # 清理空格
                processed_header = self.clean_spaces(str(header))
                # 全角转半角
                processed_header = self.full_to_half(processed_header)
                processed_headers.append(processed_header)
        return processed_headers
    
    def process_row(self, row: List[Any], headers: List[str] = None) -> List[Any]:
        """处理一行数据
        
        Args:
            row: 原始行数据
            headers: 表头信息，用于数据类型标准化
            
        Returns:
            List: 处理后的行数据
        """
        processed_row = []
        for i, cell in enumerate(row):
            processed_cell = self.process_cell(cell)
            # 尝试根据字段名称进行数据类型标准化
            if headers and i < len(headers):
                processed_cell = self.normalize_data_type(processed_cell, headers[i])
            processed_row.append(processed_cell)
        return processed_row
    
    def process_cell(self, cell: Any) -> Any:
        """处理单个单元格
        
        Args:
            cell: 原始单元格数据
            
        Returns:
            Any: 处理后的单元格数据
        """
        # 处理空值
        if cell is None:
            return None
        
        # 处理字符串类型
        if isinstance(cell, str):
            # 清理空格
            cell = self.clean_spaces(cell)
            
            # 检查是否为空值占位符
            if cell in self.null_placeholders:
                return None
            
            # 全角转半角
            cell = self.full_to_half(cell)
        
        return cell
    

    
    def normalize_data_type(self, value: Any, header: str = None) -> Any:
        """标准化数据类型
        
        Args:
            value: 原始值
            header: 字段名称，用于确定数据类型
            
        Returns:
            Any: 标准化后的值
        """
        # 处理空值
        if value is None:
            return None
        
        # 处理NaN值
        if isinstance(value, float) and value != value:
            return None
        
        # 根据字段名称确定数据类型
        if header:
            # 金额字段
            if any(keyword in header for keyword in ['交易金额', '借方金额', '贷方金额', '账户余额']):
                original_value = value
                normalized_value, currency = self._normalize_amount(value)
                if original_value != normalized_value:
                    self.logger.info(f"字段 '{header}' 金额标准化: {original_value} -> {normalized_value}")
                # 注意：币种信息需要在调用方处理，这里只返回金额
                return normalized_value
            # 日期字段
            elif any(keyword in header for keyword in ['交易日期']):
                original_value = value
                if isinstance(value, str):
                    # 保留完整的日期时间格式，不去除时分秒信息
                    # 时分秒信息将在后续的 datetime_processor 中处理
                    normalized_value = value
                elif isinstance(value, (int, float)):
                    # 处理Excel序列号格式的日期
                    try:
                        import datetime
                        # Excel序列号从1900年1月1日开始
                        dt = datetime.datetime(1899, 12, 30) + datetime.timedelta(days=float(value))
                        # 过滤不合理的日期范围（1990年至当前年份）
                        current_year = datetime.datetime.now().year
                        if 1990 <= dt.year <= current_year:
                            normalized_value = dt.strftime('%Y-%m-%d')
                        else:
                            # 日期超出合理范围，返回None
                            normalized_value = None
                    except:
                        normalized_value = None
                else:
                    normalized_value = value
                if original_value != normalized_value:
                    if normalized_value is not None:
                        self.logger.info(f"字段 '{header}' 日期标准化: {original_value} -> {normalized_value}")
                    else:
                        self.logger.info(f"字段 '{header}' 日期标准化: {original_value} -> None (不合理日期)")
                return normalized_value
            # 时间字段
            elif any(keyword in header for keyword in ['交易时间']):
                original_value = value
                if isinstance(value, str):
                    # 直接返回原值，时间标准化由 datetime_processor 处理
                    normalized_value = value
                else:
                    normalized_value = value
                if original_value != normalized_value:
                    self.logger.info(f"字段 '{header}' 时间标准化: {original_value} -> {normalized_value}")
                return normalized_value
            # 账号/卡号字段
            elif any(keyword in header for keyword in ['本方账号', '本方卡号', '交易对方账号', '交易对方卡号', '交易流水号', '柜员号']):
                original_value = value
                if isinstance(value, (int, float)):
                    # 处理NaN值
                    if isinstance(value, float) and value != value:  # NaN检测
                        return None
                    normalized_value = str(int(value))
                elif isinstance(value, str):
                    # 清理账号/卡号中的空格和特殊字符
                    cleaned = re.sub(r'[\s-]+', '', value.strip())
                    # 银行卡号验证和补全
                    if any(keyword in header for keyword in ['本方卡号', '交易对方卡号']):
                        normalized_value = self._normalize_card_number(cleaned)
                    else:
                        normalized_value = cleaned
                else:
                    normalized_value = value
                if original_value != normalized_value:
                    self.logger.info(f"字段 '{header}' 账号/卡号标准化: {original_value} -> {normalized_value}")
                return normalized_value

            # 币种字段
            elif any(keyword in header for keyword in ['币种']):
                original_value = value
                if value in self.rmb_identifiers or (isinstance(value, str) and value.strip() in self.rmb_identifiers):
                    normalized_value = '人民币'
                else:
                    normalized_value = value
                if original_value != normalized_value:
                    self.logger.info(f"字段 '{header}' 币种标准化: {original_value} -> {normalized_value}")
                return normalized_value
        
        return value
    

    

    
    def _normalize_card_number(self, card_number: str) -> str:
        """标准化银行卡号
        
        Args:
            card_number: 原始银行卡号
            
        Returns:
            str: 标准化后的银行卡号
        """
        # 只清理空格，保留"-"和字母
        cleaned = re.sub(r'\s+', '', card_number)
        
        # 验证银行卡号长度（13-19位）
        if len(cleaned) < 13 or len(cleaned) > 19:
            return cleaned
        
        # 对于纯数字的卡号，使用Luhn算法验证
        if cleaned.replace('-', '').isdigit():
            # 清理"-"后验证
            digits_only = cleaned.replace('-', '')
            if self._luhn_check(digits_only):
                return cleaned
            else:
                # 尝试修复银行卡号（如果可能）
                fixed = self._fix_card_number(digits_only)
                # 保持原始格式
                return cleaned
        else:
            # 包含字母的卡号，直接返回
            return cleaned
    
    def _luhn_check(self, card_number: str) -> bool:
        """使用Luhn算法验证银行卡号
        
        Args:
            card_number: 银行卡号
            
        Returns:
            bool: 是否有效
        """
        if not card_number.isdigit():
            return False
        
        digits = [int(d) for d in card_number]
        check_sum = 0
        
        # 从右到左遍历
        for i, digit in enumerate(reversed(digits)):
            if i % 2 == 1:  # 奇数位置（从0开始计数）
                doubled = digit * 2
                if doubled > 9:
                    doubled -= 9
                check_sum += doubled
            else:
                check_sum += digit
        
        return check_sum % 10 == 0
    
    def _fix_card_number(self, card_number: str) -> str:
        """尝试修复银行卡号
        
        Args:
            card_number: 银行卡号
            
        Returns:
            str: 修复后的银行卡号
        """
        # 这里仅作为示例，实际修复逻辑可能更复杂
        # 目前仅返回原始卡号
        return card_number
    
    def _normalize_amount(self, value: Any) -> tuple:
        """标准化金额值
        
        Args:
            value: 原始金额值
            
        Returns:
            tuple: (标准化后的值, 币种)，无法标准化时返回(None, None)
        """
        from decimal import Decimal, InvalidOperation
        
        currency = None
        
        if isinstance(value, (int, float)):
            try:
                # 使用Decimal确保精度
                normalized_amount = float(Decimal(str(value)).quantize(Decimal('0.00')))
                return normalized_amount, currency
            except (InvalidOperation, ValueError):
                return None, None
        elif isinstance(value, str):
            import re
            # 清理字符串
            cleaned = value.strip()
            
            # 识别货币符号并确定币种
            if '￥' in cleaned or '¥' in cleaned:
                currency = '人民币'
            elif '$' in cleaned:
                currency = '美元'
            
            # 移除货币符号和千分位
            cleaned = re.sub(r'[￥$¥,]', '', cleaned)
            
            # 尝试转换为Decimal
            try:
                normalized_amount = float(Decimal(cleaned).quantize(Decimal('0.00')))
                return normalized_amount, currency
            except (ValueError, TypeError, InvalidOperation):
                # 无法标准化为金额的返回(None, None)
                return None, None
        return None, None
    
    def clean_spaces(self, text: str) -> str:
        """清理空格
        
        Args:
            text: 原始文本
            
        Returns:
            str: 清理后的文本
        """
        # 去除前后空格
        text = text.strip()
        # 替换连续多个空格为单个空格
        text = re.sub(r'\s+', ' ', text)
        # 去除不可见字符
        text = re.sub(r'[\n\t\r]', '', text)
        return text
    
    def full_to_half(self, text: str) -> str:
        """全角转半角
        
        Args:
            text: 原始文本
            
        Returns:
            str: 转换后的文本
        """
        result = []
        for char in text:
            code = ord(char)
            # 全角空格转半角空格
            if code == 12288:
                result.append(' ')
            # 全角字符转半角
            elif 65281 <= code <= 65374:
                result.append(chr(code - 65248))
            else:
                result.append(char)
        return ''.join(result)
