#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
银行流水数据清洗程序主入口
"""

import os
import sys
import logging
import time
from datetime import datetime
import psutil
import pandas as pd

from reader import ExcelReader
from preprocessor import DataPreprocessor
from validator import DataValidator
from cleaner import DataCleaner
from writer import ExcelWriter
from datetime_processor import DateTimeProcessor
from logger import setup_logger
from config import Config

# 设置pandas选项以提高性能
pd.set_option('display.max_columns', None)
pd.set_option('display.max_rows', None)
pd.set_option('mode.chained_assignment', None)

class HardwareMonitor:
    """硬件监控类"""
    
    def __init__(self):
        """初始化"""
        # 动态计算最大CPU和内存使用率阈值
        import psutil
        self.cpu_count = psutil.cpu_count()
        self.total_memory = psutil.virtual_memory().total
        
        # 根据硬件配置动态调整阈值
        # 对于CPU核心数较少的机器，使用较低的阈值
        if self.cpu_count <= 2:
            self.max_cpu_percent = 70
        elif self.cpu_count <= 4:
            self.max_cpu_percent = 80
        else:
            self.max_cpu_percent = 90
        
        # 根据内存大小动态调整阈值
        memory_gb = self.total_memory / (1024 * 1024 * 1024)
        if memory_gb <= 4:
            self.max_memory_percent = 75
        elif memory_gb <= 8:
            self.max_memory_percent = 80
        else:
            self.max_memory_percent = 90
        
        # 记录硬件配置和阈值
        logger = logging.getLogger(__name__)
        logger.info(f"硬件配置 - CPU核心数: {self.cpu_count}, 总内存: {memory_gb:.2f}GB")
        logger.info(f"动态设置资源使用阈值 - CPU: {self.max_cpu_percent}%, 内存: {self.max_memory_percent}%")
        
    def get_cpu_usage(self):
        """获取当前CPU使用率"""
        return psutil.cpu_percent(interval=0.1)
    
    def get_memory_usage(self):
        """获取当前内存使用率"""
        return psutil.virtual_memory().percent
    
    def should_throttle(self):
        """检查是否需要限流"""
        cpu_usage = self.get_cpu_usage()
        memory_usage = self.get_memory_usage()
        
        # 只有当CPU或内存使用率超过阈值的90%时才考虑限流
        # 这样可以在资源充足时充分利用系统资源
        return cpu_usage > self.max_cpu_percent * 0.9 or memory_usage > self.max_memory_percent * 0.9
    
    def throttle(self):
        """执行限流"""
        # 根据系统负载动态调整睡眠时间
        cpu_usage = self.get_cpu_usage()
        memory_usage = self.get_memory_usage()
        
        # 计算负载比例
        cpu_load = cpu_usage / self.max_cpu_percent
        memory_load = memory_usage / self.max_memory_percent
        load_factor = max(cpu_load, memory_load)
        
        # 根据负载动态调整睡眠时间（0.1秒到1秒之间）
        # 减少睡眠时间，避免过度限流
        sleep_time = min(1.0, max(0.1, load_factor * 0.2))
        time.sleep(sleep_time)
    
    def log_usage(self, logger):
        """记录硬件使用情况"""
        cpu_usage = self.get_cpu_usage()
        memory_usage = self.get_memory_usage()
        logger.info(f"硬件使用情况 - CPU: {cpu_usage:.1f}%, 内存: {memory_usage:.1f}%")

# 创建全局硬件监控实例
hw_monitor = HardwareMonitor()

class DataProcessor:
    """数据处理器，支持分批处理和并行处理"""
    
    def __init__(self, batch_size=None, data_complexity=1.0):
        """初始化
        
        Args:
            batch_size: 批处理大小，如果为None则根据硬件配置自动计算
            data_complexity: 数据复杂度因子，默认为1.0，复杂数据可设置更高值
        """
        if batch_size is None:
            # 根据硬件配置自动计算批处理大小
            import psutil
            # 获取CPU核心数
            cpu_count = psutil.cpu_count()
            # 获取可用内存（GB）
            available_memory = psutil.virtual_memory().available / (1024 * 1024 * 1024)
            # 获取总内存（GB）
            total_memory = psutil.virtual_memory().total / (1024 * 1024 * 1024)
            
            # 根据硬件配置动态计算批处理大小
            # 基础批处理大小（根据CPU核心数）
            base_batch_size = 2000 * cpu_count
            
            # 根据可用内存调整（每GB可用内存增加1000条记录）
            memory_factor = int(available_memory * 1000)
            
            # 计算最终批处理大小，考虑数据复杂度
            self.batch_size = int((base_batch_size + memory_factor) / data_complexity)
            
            # 根据总内存设置合理的下限，不设置上限
            if total_memory <= 4:
                self.batch_size = max(1000, self.batch_size)
            elif total_memory <= 8:
                self.batch_size = max(2000, self.batch_size)
            else:
                self.batch_size = max(3000, self.batch_size)
            
            # 记录自动计算的批处理大小
            logger = logging.getLogger(__name__)
            logger.info(f"根据硬件配置自动设置批处理大小: {self.batch_size} (CPU核心数: {cpu_count}, 可用内存: {available_memory:.2f}GB, 总内存: {total_memory:.2f}GB, 数据复杂度: {data_complexity})")
        else:
            self.batch_size = batch_size
    
    def process_in_batches(self, data, process_func, logger):
        """分批处理数据
        
        Args:
            data: 原始数据
            process_func: 处理函数
            logger: 日志记录器
            
        Returns:
            处理后的数据
        """
        if not data:
            return []
        
        processed_data = []
        total_batches = (len(data) + self.batch_size - 1) // self.batch_size
        
        for i in range(total_batches):
            start_idx = i * self.batch_size
            end_idx = min((i + 1) * self.batch_size, len(data))
            batch = data[start_idx:end_idx]
            
            logger.info(f"处理批次 {i+1}/{total_batches}，处理 {len(batch)} 行数据")
            
            # 检查硬件使用情况
            hw_monitor.log_usage(logger)
            
            # 处理批次数据
            batch_result = process_func(batch)
            processed_data.extend(batch_result)
            
            # 检查是否需要限流
            while hw_monitor.should_throttle():
                logger.warning("硬件使用率过高，执行限流")
                hw_monitor.throttle()
        
        return processed_data
    
    def process_in_parallel(self, data, process_func, logger, max_workers=None):
        """并行处理数据
        
        Args:
            data: 原始数据
            process_func: 处理函数
            logger: 日志记录器
            max_workers: 最大工作线程数，如果为None则根据硬件配置自动计算
            
        Returns:
            处理后的数据
        """
        if not data:
            return []
        
        import concurrent.futures
        import psutil
        
        # 获取CPU核心数
        cpu_count = psutil.cpu_count()
        # 获取可用内存（GB）
        available_memory = psutil.virtual_memory().available / (1024 * 1024 * 1024)
        
        if max_workers is None:
            # 根据硬件配置动态调整并行度
            # 基础并行度 - 使用所有可用核心
            base_workers = cpu_count
            
            # 根据可用内存调整并行度（每1GB内存增加1个工作线程）
            memory_workers = int(available_memory)
            
            # 计算最终并行度
            max_workers = min(cpu_count * 2, base_workers + memory_workers)
            
            # 确保并行度合理（只设置下限，不设置上限）
            max_workers = max(2, max_workers)  # 至少使用2个核心
        
        # 计算每个工作线程处理的批次大小
        batch_size = max(500, len(data) // (max_workers * 4))  # 更小的批次大小，增加并行度
        total_batches = (len(data) + batch_size - 1) // batch_size
        
        logger.info(f"启动并行处理，使用 {max_workers} 个工作线程，共 {total_batches} 个批次")
        
        processed_data = []
        
        # 划分数据批次
        batches = []
        for i in range(total_batches):
            start_idx = i * batch_size
            end_idx = min((i + 1) * batch_size, len(data))
            batches.append(data[start_idx:end_idx])
        
        # 使用线程池并行处理
        with concurrent.futures.ThreadPoolExecutor(max_workers=max_workers) as executor:
            # 提交所有批次到线程池
            future_to_batch = {executor.submit(process_func, batch): i for i, batch in enumerate(batches)}
            
            # 处理结果
            for future in concurrent.futures.as_completed(future_to_batch):
                batch_idx = future_to_batch[future]
                try:
                    batch_result = future.result()
                    processed_data.extend(batch_result)
                    logger.info(f"并行处理完成批次 {batch_idx+1}/{total_batches}")
                except Exception as e:
                    logger.error(f"并行处理批次 {batch_idx+1} 时发生错误: {str(e)}")
        
        logger.info(f"并行处理完成，共处理 {len(processed_data)} 行数据")
        return processed_data

def main():
    """主函数"""
    # 固定设置输入输出路径
    input_path = "E:\数据清洗\原始数据"
    output_path = "E:\数据清洗"
    # 使用程序目录中的流水汇总模板
    template_file = os.path.join(os.path.dirname(__file__), "流水汇总模板.xlsx")
    log_level = "INFO"
    
    # 要求使用者输入此次汇总流水的所有对象名称
    print("请输入此次汇总流水的所有对象名称（以逗号、顿号作为分隔符）：")
    user_input = input().strip()
    # 解析输入的对象名称
    import re
    object_names = re.split(r'[,，、]', user_input)
    # 清理空白名称
    object_names = [name.strip() for name in object_names if name.strip()]
    print(f"已识别 {len(object_names)} 个对象名称")
    
    # 检查输入路径是否存在
    if not os.path.exists(input_path):
        print(f"错误: 输入路径 '{input_path}' 不存在")
        sys.exit(1)
    
    # 检查模板文件是否存在
    if not os.path.exists(template_file):
        print(f"错误: 模板文件 '{template_file}' 不存在")
        sys.exit(1)
    
    # 设置日志
    log_file = f"logs/cleaning_log_{datetime.now().strftime('%Y%m%d_%H%M%S')}.log"
    setup_logger(log_level=log_level, log_file=log_file, enable_rotation=True)
    logger = logging.getLogger(__name__)
    
    print(f"输入路径: {input_path}")
    print(f"输出路径: {output_path}")
    print(f"模板文件: {template_file}")
    print(f"日志级别: {log_level}")
    print()
    
    # 检查输入路径类型
    if os.path.isfile(input_path):
        # 处理单个文件
        process_single_file(input_path, output_path, template_file, logger, object_names)
    elif os.path.isdir(input_path):
        # 处理文件夹
        process_folder(input_path, output_path, template_file, logger, object_names)
    else:
        print(f"错误: 输入路径 '{input_path}' 不存在")
        sys.exit(1)

def process_single_file(input_file, output_path, template_file, logger, object_names=None):
    """处理单个文件"""
    # 检查是否为临时文件
    base_name = os.path.basename(input_file)
    if base_name.startswith('~$'):
        logger.info(f"跳过临时文件: {input_file}")
        print(f"跳过临时文件: {input_file}")
        return
    
    logger.info(f"开始处理文件: {input_file}")
    logger.info(f"使用模板: {template_file}")
    
    # 生成输出文件名
    if output_path:
        if os.path.isdir(output_path):
            # 如果输出路径是文件夹，生成文件名
            name, ext = os.path.splitext(base_name)
            output_file = os.path.join(output_path, f"{name}_清洗后{ext}")
        else:
            # 如果输出路径是文件，直接使用
            output_file = output_path
    else:
        # 默认输出到当前目录
        name, ext = os.path.splitext(base_name)
        output_file = f"{name}_清洗后{ext}"
    
    logger.info(f"输出文件: {output_file}")
    
    # 使用单输出函数处理文件
    success = process_excel_file(input_file, output_file, template_file, logger, object_names)
    
    if success:
        print(f"\n✅ 数据清洗完成！")
        print(f"📁 清洗后数据: {output_file}")
    else:
        sys.exit(1)

def process_excel_file(input_file, output_file, template_file, logger, object_names=None):
    """处理单个Excel文件的公共逻辑"""
    try:
        # 1. 读取数据
        logger.info("步骤1: 读取数据")
        reader = ExcelReader(input_file)
        sheets_data = reader.read_all_sheets()
        
        # 2. 数据预处理和合并
        logger.info("步骤2: 数据预处理")
        preprocessor = DataPreprocessor()
        
        # 处理每个sheet的数据
        processed_data = []
        all_headers = []
        
        for sheet_name, sheet_content in sheets_data.items():
            logger.info(f"处理sheet: {sheet_name}")
            headers = sheet_content['headers']
            all_headers.append(headers)
            
            # 预处理当前sheet的数据
            sheet_processed = [preprocessor.process_row(row, headers) for row in sheet_content['data']]
            processed_data.extend(sheet_processed)
        
        # 选择最完整的表头作为主表头
        main_headers = max(all_headers, key=len)
        logger.info(f"总数据量: {len(processed_data)} 行")
        
        # 检查硬件使用情况
        hw_monitor.log_usage(logger)
        
        # 3. 数据校验
        logger.info("步骤3: 数据校验")
        validator = DataValidator()
        
        # 执行字段完整性校验
        is_valid, missing_fields = validator.validate_field_completeness(main_headers)
        
        if not is_valid:
            logger.warning(f"缺少必需字段: {missing_fields}")
            logger.warning("将继续处理，但数据可能不完整")
        else:
            logger.info("字段完整性校验通过")
        
        # 并行校验数据
        data_processor = DataProcessor()  # 不指定batch_size，使用自动计算的批处理大小
        validated_data = data_processor.process_in_parallel(
            processed_data, 
            lambda batch: validator.validate_batch(batch, main_headers),
            logger
        )
        
        # 过滤掉无效行（validator返回的None值）
        validated_data = [row for row in validated_data if row is not None]
        logger.info(f"校验后有效数据量: {len(validated_data)} 行")
        
        # 4. 数据清洗
        logger.info("步骤4: 数据清洗")
        cleaner = DataCleaner()
        
        # 执行完整的清洗流程
        # 1. 过滤无效行（全为空的行）
        filtered_rows = [row for row in validated_data if not cleaner.is_all_empty(row, main_headers)]
        
        # 2. 删除重复和留空行
        duplicate_removed = cleaner.remove_duplicate_and_empty_rows(filtered_rows, main_headers)
        
        # 4. 计算交易金额
        cleaned_data, final_headers = cleaner.calculate_transaction_amount(duplicate_removed, main_headers)
        
        # 5. 统一借贷标志
        cleaned_data = cleaner.unify_debit_credit(cleaned_data, final_headers)
        
        # 6. 处理TenpayTrades.txt数据，将交易金额和账户余额除以100
        cleaned_data = cleaner.process_tenpay_data(cleaned_data, final_headers)
        
        # 7. 提取信息（根据银行卡号/账号对应开户行，从文件名提取信息）
        cleaned_data, final_headers = cleaner.extract_information(cleaned_data, final_headers, input_file, object_names)
        
        # 7. 匹配户主名称
        cleaned_data, matched_rows = cleaner.match_account_holder(cleaned_data, final_headers)
        
        # 8. 标准化交易日期和交易时间，处理日期中的时分秒信息
        datetime_processor = DateTimeProcessor()
        cleaned_data = datetime_processor.normalize_datetime_columns(cleaned_data, final_headers)
        
        # 9. 合并交易日期和交易时间列，并删除1990年之前的数据
        cleaned_data, final_headers = datetime_processor.merge_datetime_columns(cleaned_data, final_headers)
        
        # 10. 并行处理剩余的清洗步骤
        data_processor = DataProcessor()
        
        # 10. 删除交易金额为0的整行数据
        cleaned_data = data_processor.process_in_parallel(
            cleaned_data, 
            lambda batch: cleaner.remove_zero_amount_rows(batch, final_headers),
            logger
        )
        
        # 11. 删除本方卡号、本方账号为全0的整行数据
        cleaned_data = data_processor.process_in_parallel(
            cleaned_data, 
            lambda batch: cleaner.remove_zero_card_account_rows(batch, final_headers),
            logger
        )
        
        logger.info(f"清洗后数据量: {len(cleaned_data)} 行")
        logger.info(f"过滤空行: {len(validated_data) - len(filtered_rows)} 行")
        logger.info(f"删除重复和无效行: {len(filtered_rows) - len(duplicate_removed)} 行")
        
        # 5. 数据输出
        logger.info("步骤5: 数据输出")
        writer = ExcelWriter(template_file, output_file)
        
        # 写入数据，不分离关键信息缺失数据（在最终汇总时处理）
        writer.write_with_missing_info_sheet(cleaned_data, [], final_headers, logger)
        
        logger.info("数据清洗完成！")
        logger.info(f"清洗后数据已保存至: {output_file}")
        
        return True
        
    except Exception as e:
        logger.error(f"处理过程中发生错误: {str(e)}")
        print(f"\n❌ 处理过程中发生错误: {str(e)}")
        import traceback
        traceback.print_exc()
        return False



def process_folder(input_folder, output_folder, template_file, logger, object_names=None):
    """处理文件夹中的所有Excel文件"""
    logger.info(f"开始处理文件夹: {input_folder}")
    logger.info(f"使用模板: {template_file}")
    
    # 确保输出文件夹存在
    if output_folder:
        if not os.path.exists(output_folder):
            os.makedirs(output_folder)
            logger.info(f"创建输出文件夹: {output_folder}")
    else:
        # 默认输出到当前目录
        output_folder = os.getcwd()
    
    logger.info(f"输出文件夹: {output_folder}")
    
    # 获取文件夹中的Excel文件
    excel_files = []
    for file in os.listdir(input_folder):
        # 跳过临时文件（以~$开头）
        if file.startswith('~$'):
            logger.info(f"跳过临时文件: {file}")
            continue
        if file.endswith('.xlsx') or file.endswith('.xls'):
            excel_files.append(os.path.join(input_folder, file))
    
    if not excel_files:
        logger.warning(f"文件夹 '{input_folder}' 中没有找到Excel文件")
        print(f"警告: 文件夹 '{input_folder}' 中没有找到Excel文件")
        return
    
    logger.info(f"找到 {len(excel_files)} 个Excel文件")
    
    # 处理每个Excel文件
    for i, input_file in enumerate(excel_files):
        logger.info(f"\n处理文件 {i+1}/{len(excel_files)}: {input_file}")
        
        # 生成输出文件名
        base_name = os.path.basename(input_file)
        name, ext = os.path.splitext(base_name)
        output_file = os.path.join(output_folder, f"{name}_清洗后{ext}")
        
        logger.info(f"输出文件: {output_file}")
        
        # 使用单输出函数处理文件
        success = process_excel_file(input_file, output_file, template_file, logger, object_names)
        
        if success:
            print(f"\n✅ 处理完成: {os.path.basename(input_file)}")
            print(f"📁 清洗后数据: {output_file}")
        else:
            continue
    
    # 重新汇总所有清洗后的分文件
    logger.info("\n步骤6: 重新汇总所有清洗后的分文件")
    
    # 收集所有清洗后的文件
    cleaned_files = []
    for file in os.listdir(output_folder):
        if file.endswith('_清洗后.xlsx') or file.endswith('_清洗后.xls'):
            cleaned_files.append(os.path.join(output_folder, file))
    
    if cleaned_files:
        logger.info(f"找到 {len(cleaned_files)} 个清洗后的文件")
        
        # 读取并合并所有清洗后的数据
        all_cleaned_data = []
        all_headers = []
        
        for cleaned_file in cleaned_files:
            logger.info(f"读取清洗后文件: {cleaned_file}")
            try:
                reader = ExcelReader(cleaned_file)
                sheets_data = reader.read_all_sheets()
                
                for sheet_name, sheet_content in sheets_data.items():
                    headers = sheet_content['headers']
                    all_headers.append(headers)
                    all_cleaned_data.extend(sheet_content['data'])
            except Exception as e:
                logger.error(f"读取清洗后文件失败: {str(e)}")
                continue
        
        if all_cleaned_data:
            logger.info(f"汇总后总数据量: {len(all_cleaned_data)} 行")
            
            # 选择最完整的表头作为主表头
            main_headers = max(all_headers, key=len)
            
            # 对汇总后的数据再次进行清洗
            logger.info("对汇总后的数据再次进行清洗")
            cleaner = DataCleaner()
            data_processor = DataProcessor()
            
            # 1. 过滤无效行
            filtered_rows = [row for row in all_cleaned_data if not cleaner.is_all_empty(row, main_headers)]
            
            # 2. 删除重复和留空行
            duplicate_removed = cleaner.remove_duplicate_and_empty_rows(filtered_rows, main_headers)
            
            # 4. 计算交易金额
            final_data, final_headers = cleaner.calculate_transaction_amount(duplicate_removed, main_headers)
            
            # 5. 统一借贷标志
            final_data = cleaner.unify_debit_credit(final_data, final_headers)
            
            # 6. 提取信息（确保在匹配户主名称之前执行）
            final_data, final_headers = cleaner.extract_information(final_data, final_headers, '', object_names)
            
            # 7. 匹配户主名称
            final_data, matched_rows = cleaner.match_account_holder(final_data, final_headers)
            
            # 7. 标准化交易日期和交易时间
            datetime_processor = DateTimeProcessor()
            final_data = datetime_processor.normalize_datetime_columns(final_data, final_headers)
            
            # 8. 合并交易日期和交易时间列，并删除1990年之前的数据
            final_data, final_headers = datetime_processor.merge_datetime_columns(final_data, final_headers)
            
            # 9. 并行删除交易金额为0的整行数据
            final_data = data_processor.process_in_parallel(
                final_data, 
                lambda batch: cleaner.remove_zero_amount_rows(batch, final_headers),
                logger
            )
            
            # 10. 并行删除本方卡号、本方账号为全0的整行数据
            final_data = data_processor.process_in_parallel(
                final_data, 
                lambda batch: cleaner.remove_zero_card_account_rows(batch, final_headers),
                logger
            )
            
            logger.info(f"再次清洗后数据量: {len(final_data)} 行")
            
            # 保存最终汇总结果
            summary_output_file = os.path.join(output_folder, f"流水汇总_最终_{datetime.now().strftime('%Y%m%d_%H%M%S')}.xlsx")
            logger.info(f"保存最终汇总结果: {summary_output_file}")
            
            writer = ExcelWriter(template_file, summary_output_file)
            writer.write_with_missing_info_sheet(final_data, [], final_headers, logger)
            
            print(f"\n📁 最终汇总结果: {summary_output_file}")
        else:
            logger.warning("没有成功读取到清洗后的数据")
    else:
        logger.warning("没有找到清洗后的文件")
    
    logger.info("\n所有文件处理完成！")
    print("\n🎉 所有文件处理完成！")

if __name__ == "__main__":
    main()
