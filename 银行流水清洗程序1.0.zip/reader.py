#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
数据读取模块
负责读取Excel文件中的所有sheet数据
"""

import logging
import pandas as pd
from typing import Dict, List, Any

class ExcelReader:
    """Excel文件读取器"""
    
    def __init__(self, file_path: str):
        """初始化
        
        Args:
            file_path: Excel文件路径
        """
        self.file_path = file_path
        self.logger = logging.getLogger(__name__)
    
    def read_all_sheets(self) -> Dict[str, Dict[str, Any]]:
        """读取所有sheet的数据
        
        Returns:
            Dict: 包含所有sheet数据的字典
                  格式: {sheet_name: {'headers': [], 'data': []}}
        """
        sheets_data = {}
        
        try:
            # 使用pandas读取Excel文件
            xls = pd.ExcelFile(self.file_path)
            
            for sheet_name in xls.sheet_names:
                self.logger.info(f"读取sheet: {sheet_name}")
                
                # 读取sheet数据，将可能的账号、卡号等字段识别为字符串
                # 先读取表头
                header_df = pd.read_excel(xls, sheet_name=sheet_name, nrows=0)
                headers = list(header_df.columns)
                
                # 识别需要作为字符串读取的列
                string_columns = []
                for header in headers:
                    if any(keyword in header for keyword in ['本方账号', '本方卡号', '交易对方账号', '交易对方卡号', '交易流水号', '柜员号', 'IP地址', 'MAC地址']):
                        string_columns.append(header)
                
                # 读取数据，指定需要作为字符串的列
                dtype = {col: str for col in string_columns}
                df = pd.read_excel(xls, sheet_name=sheet_name, dtype=dtype)
                
                # 获取表头
                headers = list(df.columns)
                
                # 转换数据为列表格式
                data = df.values.tolist()
                
                sheets_data[sheet_name] = {
                    'headers': headers,
                    'data': data
                }
                
                self.logger.info(f"Sheet '{sheet_name}' 读取完成，共 {len(data)} 行数据")
                
        except Exception as e:
            self.logger.error(f"读取Excel文件失败: {str(e)}")
            raise
        
        return sheets_data
    

