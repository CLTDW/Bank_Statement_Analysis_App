#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
数据清洗模块
负责数据的清洗工作，包括处理无效数据、合并数据等
"""

import logging
import os
from typing import Dict, List, Any, Tuple

class DataCleaner:
    """数据清洗器"""
    
    # 公司名前缀列表
    COMPANY_PREFIXES = ['中国', '北京', '上海', '广州', '深圳', '杭州', '成都', '武汉', '西安', '南京', '重庆', '天津', '苏州', '郑州', '长沙', '青岛', '宁波', '厦门', '福州', '济南', '大连', '哈尔滨', '合肥', '昆明', '贵阳', '南宁', '南昌', '太原', '石家庄', '乌鲁木齐', '兰州', '西宁', '银川', '拉萨', '香港', '澳门', '台湾', '国际', '环球', '全国', '亚洲', '太平洋']
    
    def __init__(self):
        """初始化"""
        self.logger = logging.getLogger(__name__)
    

    
    def is_all_empty(self, row: List[Any], headers: List[str] = None) -> bool:
        """检查是否为全空行
        
        Args:
            row: 行数据
            headers: 表头信息，用于识别有效列
            
        Returns:
            bool: 是否为全空行
        """
        from config import Config
        
        # 有效表头列（用于全空行检测）
        valid_headers = Config.VALID_HEADERS
        
        # 如果没有提供表头信息，检查所有列
        if headers is None:
            for cell in row:
                if cell is not None:
                    # 检查字符串是否为空
                    if isinstance(cell, str):
                        if cell.strip():
                            return False
                    else:
                        return False
            return True
        
        # 仅检查有效表头列对应的单元格
        for i, (header, cell) in enumerate(zip(headers, row)):
            # 跳过序号、数据来源等非有效表头列
            # 只检查在valid_headers中的列
            if header in valid_headers:
                if cell is not None:
                    # 检查字符串是否为空
                    if isinstance(cell, str):
                        if cell.strip():
                            return False
                    else:
                        return False
        
        return True

    def remove_duplicate_and_empty_rows(self, rows: List[List[Any]], headers: List[str]) -> List[List[Any]]:
        """删除指定列中数据同时重复的行数据以及留空行数据
        
        Args:
            rows: 数据行
            headers: 表头信息
            
        Returns:
            List: 删除重复行和留空行后的数据行
        """
        # 指定需要检查重复的列（根据要求）
        duplicate_check_columns = [
            '借贷标志', '交易金额', '账户余额'
        ]
        
        # 关键列（用于判断是否为有效行）
        key_columns = ['交易日期', '交易时间', '借方金额', '贷方金额', '交易金额']
        
        # 查找指定列的索引
        duplicate_check_indices = []
        key_indices = []
        
        for i, header in enumerate(headers):
            if header in duplicate_check_columns:
                duplicate_check_indices.append(i)
            if header in key_columns:
                key_indices.append(i)
        
        cleaned_rows = []
        seen_rows = {}
        empty_rows_count = 0
        invalid_rows_count = 0
        duplicate_rows_count = 0
        
        # 计算行内有效信息数量的函数
        def count_valid_info(row):
            count = 0
            for cell in row:
                if cell is not None:
                    if isinstance(cell, str):
                        if cell.strip():
                            count += 1
                    else:
                        count += 1
            return count
        
        for row in rows:
            # 提取指定列的值用于重复检查
            row_key = []
            is_empty_row = True
            has_required_data = False
            
            # 检查关键列是否为空
            for idx in key_indices:
                if idx < len(row):
                    cell = row[idx]
                    if cell is not None:
                        if isinstance(cell, str):
                            if cell.strip():
                                is_empty_row = False
                                has_required_data = True
                        else:
                            is_empty_row = False
                            has_required_data = True
            
            # 增强的数据完整性检查
            # 至少需要交易日期和金额信息
            has_date = False
            has_amount = False
            has_any_data = False
            
            for i, header in enumerate(headers):
                if i >= len(row):
                    continue
                
                cell = row[i]
                if cell is None:
                    continue
                
                has_any_data = True
                
                if isinstance(cell, str) and not cell.strip():
                    continue
                
                if '交易日期' in header or '发生日期' in header:
                    has_date = True
                elif '交易金额' in header or '金额' in header:
                    has_amount = True
                elif '借方金额' in header or '贷方金额' in header:
                    has_amount = True
            
            # 更加宽松的数据完整性检查
            # 只在完全没有任何数据时才视为无效行
            # 如果有任何数据，就保留该行
            if not has_any_data:
                invalid_rows_count += 1
                continue
            
            # 提取用于重复检查的列的值
            for idx in duplicate_check_indices:
                if idx < len(row):
                    cell = row[idx]
                    if cell is None:
                        row_key.append(None)
                    elif isinstance(cell, str):
                        row_key.append(cell.strip())
                    else:
                        row_key.append(cell)
                else:
                    row_key.append(None)
            
            # 检查是否为留空行
            # 更加宽松的判断：只有当所有列都为空时才视为留空行
            all_empty = True
            for cell in row:
                if cell is not None:
                    if isinstance(cell, str):
                        if cell.strip():
                            all_empty = False
                            break
                    else:
                        all_empty = False
                        break
            
            if all_empty:
                empty_rows_count += 1
                continue
            
            # 检查是否为重复行
            # 只有当3个列均为非空值时才进行重复检查
            all_non_empty = all(val is not None for val in row_key)
            if all_non_empty:
                row_tuple = tuple(row_key)
                if row_tuple not in seen_rows:
                    # 记录该行及其有效信息数量
                    seen_rows[row_tuple] = (row, count_valid_info(row))
                    cleaned_rows.append(row)
                else:
                    # 比较当前行和已保存行的有效信息数量
                    existing_row, existing_count = seen_rows[row_tuple]
                    current_count = count_valid_info(row)
                    
                    if current_count > existing_count:
                        # 替换为有效信息更多的行
                        seen_rows[row_tuple] = (row, current_count)
                        # 从cleaned_rows中移除旧行，添加新行
                        cleaned_rows.remove(existing_row)
                        cleaned_rows.append(row)
                    
                    duplicate_rows_count += 1
            else:
                # 非空值少于3个，直接保留该行
                cleaned_rows.append(row)
        
        self.logger.info(f"删除了 {empty_rows_count} 个空白行、{invalid_rows_count} 个无效行和 {duplicate_rows_count} 个重复行")
        self.logger.info(f"保留了 {len(cleaned_rows)} 行数据")
        return cleaned_rows
    
    def calculate_transaction_amount(self, rows: List[List[Any]], headers: List[str]) -> Tuple[List[List[Any]], List[str]]:
        """计算交易金额：贷方金额减去借方金额
        
        Args:
            rows: 数据行
            headers: 表头信息
            
        Returns:
            Tuple[List[List[Any]], List[str]]: (计算交易金额后的数据行, 更新后的表头)
        """
        import re
        from typing import Tuple
        
        # 复制表头，避免修改原始表头
        updated_headers = headers.copy()
        
        # 查找借方金额、贷方金额、交易金额和借贷标志的列索引
        debit_col = -1
        credit_col = -1
        amount_col = -1
        debit_credit_col = -1
        
        # 更详细的列名匹配选项（扩展）
        debit_keywords = [
            '借方金额'
        ]
        credit_keywords = [
            '贷方金额'
        ]
        amount_keywords = [
            '交易金额'
        ]
        debit_credit_keywords = [
            '借贷标志'
        ]
        
        for i, header in enumerate(updated_headers):
            # 查找借方金额列
            if any(keyword in header for keyword in debit_keywords):
                debit_col = i
            # 查找贷方金额列
            elif any(keyword in header for keyword in credit_keywords):
                credit_col = i
            # 查找交易金额列
            elif any(keyword in header for keyword in amount_keywords):
                amount_col = i
            # 查找借贷标志列
            elif any(keyword in header for keyword in debit_credit_keywords):
                debit_credit_col = i
        
        # 如果没有借贷标志列，添加一个
        if debit_credit_col == -1:
            updated_headers.append('借贷标志')
            debit_credit_col = len(updated_headers) - 1
            for row in rows:
                while len(row) < len(updated_headers):
                    row.append(None)
        
        # 输出调试信息
        self.logger.info(f"查找列索引 - 交易金额: {amount_col}, 借方金额: {debit_col}, 贷方金额: {credit_col}, 借贷标志: {debit_credit_col}")
        
        # 导入预处理器的金额标准化功能
        from preprocessor import DataPreprocessor
        from decimal import Decimal, InvalidOperation
        preprocessor = DataPreprocessor()
        
        # 辅助函数：获取金额值，处理None值
        def get_amount(value):
            if value is None:
                return 0
            normalized = preprocessor._normalize_amount(value)
            # 处理返回的元组 (金额, 币种)
            if isinstance(normalized, tuple):
                amount = normalized[0]
                return amount if amount is not None else 0
            return normalized if normalized is not None else 0
        
        # 辅助函数：处理交易金额格式（保持原值，不进行归正）
        def normalize_amount_and_debit_credit(row):
            if len(row) > amount_col:
                amount = row[amount_col]
                if amount is not None:
                    # 解析金额
                    parsed_amount = get_amount(amount)
                    # 保持金额原值（包括负数），不进行归正
                    # 使用Decimal确保精度
                    try:
                        row[amount_col] = float(Decimal(str(parsed_amount)).quantize(Decimal('0.00')))
                    except:
                        row[amount_col] = round(parsed_amount, 2)
                    # 保持原借贷标志不变，不进行推断
            return False
        
        # 计算交易金额
        calculated_count = 0
        added_column_count = 0
        normalized_count = 0
        
        # 情况1: 有交易金额列，也有借方和贷方金额列
        if amount_col != -1 and debit_col != -1 and credit_col != -1:
            for i, row in enumerate(rows):
                # 检查交易金额是否为空
                if len(row) > amount_col:
                    transaction_amount = row[amount_col]
                    # 如果交易金额为空或为0，计算它
                    if (transaction_amount is None or 
                        (isinstance(transaction_amount, str) and not transaction_amount.strip()) or
                        (isinstance(transaction_amount, (int, float)) and transaction_amount == 0)):
                        # 获取借方金额和贷方金额
                        debit_amount = get_amount(row[debit_col] if len(row) > debit_col else None)
                        credit_amount = get_amount(row[credit_col] if len(row) > credit_col else None)
                        
                        # 计算交易金额：贷方金额减去借方金额
                        calculated_amount = credit_amount - debit_amount
                        row[amount_col] = calculated_amount
                        calculated_count += 1
                        # 只记录前100行和最后100行的计算情况，避免日志过多
                        if i < 100 or i >= len(rows) - 100:
                            self.logger.info(f"行 {i+1}: 计算交易金额 = 贷方金额({credit_amount}) - 借方金额({debit_amount}) = {calculated_amount}")
                        elif i == 100:
                            self.logger.info(f"... 省略中间 {len(rows) - 200} 行的计算日志 ...")
                
                # 处理交易金额归正和借贷标志
                if normalize_amount_and_debit_credit(row):
                    normalized_count += 1
        # 情况2: 只有借方和贷方金额列，没有交易金额列
        elif debit_col != -1 and credit_col != -1 and amount_col == -1:
            self.logger.info("未找到交易金额列，将添加新列")
            # 添加交易金额列到表头
            updated_headers.append('交易金额')
            amount_col = len(updated_headers) - 1
            # 为每行计算并添加交易金额
            for i, row in enumerate(rows):
                # 确保行长度足够
                while len(row) < len(updated_headers):
                    row.append(None)
                # 计算交易金额
                debit_amount = get_amount(row[debit_col] if len(row) > debit_col else None)
                credit_amount = get_amount(row[credit_col] if len(row) > credit_col else None)
                calculated_amount = credit_amount - debit_amount
                row[amount_col] = calculated_amount
                calculated_count += 1
                added_column_count += 1
                # 只记录前100行和最后100行的计算情况，避免日志过多
                if i < 100 or i >= len(rows) - 100:
                    self.logger.info(f"行 {i+1}: 添加并计算交易金额 = 贷方金额({credit_amount}) - 借方金额({debit_amount}) = {calculated_amount}")
                elif i == 100:
                    self.logger.info(f"... 省略中间 {len(rows) - 200} 行的计算日志 ...")
                
                # 处理交易金额归正和借贷标志
                if normalize_amount_and_debit_credit(row):
                    normalized_count += 1
        # 情况3: 只有交易金额列，没有借方和贷方金额列
        elif amount_col != -1 and (debit_col == -1 or credit_col == -1):
            self.logger.info("未找到借方或贷方金额列，仅验证交易金额格式")
            # 验证并清理交易金额格式
            for i, row in enumerate(rows):
                if len(row) > amount_col:
                    original_amount = row[amount_col]
                    parsed_amount = get_amount(original_amount)
                    if parsed_amount != 0 or original_amount is not None:
                        row[amount_col] = parsed_amount
                        calculated_count += 1
                        if original_amount != parsed_amount:
                            self.logger.info(f"行 {i+1}: 标准化交易金额格式: {original_amount} -> {parsed_amount}")
                    
                    # 处理交易金额归正和借贷标志
                    if normalize_amount_and_debit_credit(row):
                        normalized_count += 1
        # 情况4: 没有任何金额列
        else:
            self.logger.warning("未找到任何金额列（交易金额、借方金额、贷方金额）")
        
        self.logger.info(f"计算了 {calculated_count} 行交易金额")
        if added_column_count > 0:
            self.logger.info(f"添加了 {added_column_count} 个交易金额列")
        if normalized_count > 0:
            self.logger.info(f"归正了 {normalized_count} 行交易金额")
        
        return rows, updated_headers
    
    def process_tenpay_data(self, rows: List[List[Any]], headers: List[str]) -> List[List[Any]]:
        """处理TenpayTrades.txt数据，将交易金额和账户余额除以100
        
        Args:
            rows: 数据行
            headers: 表头信息
            
        Returns:
            List[List[Any]]: 处理后的数据行
        """
        import re
        from decimal import Decimal, InvalidOperation
        
        # 查找数据来源、交易金额和账户余额的列索引
        data_source_col = -1
        amount_col = -1
        balance_col = -1
        
        for i, header in enumerate(headers):
            if '数据来源' in header:
                data_source_col = i
            elif '交易金额' in header:
                amount_col = i
            elif '账户余额' in header:
                balance_col = i
        
        if data_source_col == -1:
            self.logger.info("未找到数据来源列，跳过Tenpay数据处理")
            return rows
        
        if amount_col == -1 and balance_col == -1:
            self.logger.info("未找到交易金额或账户余额列，跳过Tenpay数据处理")
            return rows
        
        processed_count = 0
        
        for i, row in enumerate(rows):
            # 检查数据来源列是否存在且有值
            if len(row) > data_source_col and row[data_source_col] is not None:
                data_source = str(row[data_source_col])
                # 检查数据来源是否为TenpayTrades.txt
                path_parts = re.split(r'[\\/]', data_source)
                file_name = path_parts[-1] if path_parts else ''
                if file_name == 'TenpayTrades.txt':
                    # 处理交易金额
                    if len(row) > amount_col and row[amount_col] is not None:
                        try:
                            # 尝试将交易金额转换为数字并除以100
                            if isinstance(row[amount_col], str):
                                # 清理字符串中的非数字字符
                                cleaned_amount = re.sub(r'[^0-9.-]', '', row[amount_col])
                                amount = float(cleaned_amount)
                            else:
                                amount = float(row[amount_col])
                            # 除以100
                            amount /= 100
                            # 使用Decimal确保精度
                            row[amount_col] = float(Decimal(str(amount)).quantize(Decimal('0.00')))
                        except:
                            pass
                    
                    # 处理账户余额
                    if len(row) > balance_col and row[balance_col] is not None:
                        try:
                            # 尝试将账户余额转换为数字并除以100
                            if isinstance(row[balance_col], str):
                                # 清理字符串中的非数字字符
                                cleaned_balance = re.sub(r'[^0-9.-]', '', row[balance_col])
                                balance = float(cleaned_balance)
                            else:
                                balance = float(row[balance_col])
                            # 除以100
                            balance /= 100
                            # 使用Decimal确保精度
                            row[balance_col] = float(Decimal(str(balance)).quantize(Decimal('0.00')))
                        except:
                            pass
                    
                    processed_count += 1
        
        if processed_count > 0:
            self.logger.info(f"处理了 {processed_count} 行TenpayTrades.txt数据，交易金额和账户余额已除以100")
        
        return rows
    
    def unify_debit_credit(self, rows: List[List[Any]], headers: List[str]) -> List[List[Any]]:
        """统一借贷标志为收入或支出
        
        Args:
            rows: 数据行
            headers: 表头信息
            
        Returns:
            List[List[Any]]: 统一借贷标志后的数据行
        """
        # 定位借贷标志列，只寻找表头内容为"借贷标志"的列
        debit_credit_col = -1
        for i, header in enumerate(headers):
            if header == '借贷标志':
                debit_credit_col = i
                break
        
        if debit_credit_col == -1:
            self.logger.info("未找到借贷标志列，跳过统一处理")
            return rows
        
        # 查找交易金额列，用于处理空白借贷标志
        amount_col = -1
        amount_keywords = [
            '交易金额'
        ]
        for i, header in enumerate(headers):
            if any(keyword in header for keyword in amount_keywords):
                amount_col = i
                break
        
        # 精准映射库
        exact_mapping = {
            # 收入映射
            '收入': '收入', '进': '收入', '贷': '收入', '贷项': '收入', 'credit': '收入', 'Credit': '收入', 'CREDIT': '收入', '贷方': '收入','C': '收入',
            '存入': '收入', '进账': '收入', '收款': '收入', '收到': '收入', '转入': '收入', 'in': '收入', 'IN': '收入', 'In': '收入', '+': '收入', '1': '收入', '入账': '收入',
            # 支出映射
            '支出': '支出', '出': '支出', '付': '支出', '借': '支出', '借项': '支出', 'debit': '支出', 'Debit': '支出', 'DEBIT': '支出', '借方': '支出','D': '支出',
            '取出': '支出', '出账': '支出', '付款': '支出', '付出': '支出', '转出': '支出', 'out': '支出', 'OUT': '支出', 'Out': '支出', '-': '支出', '0': '支出'
        }
        
        # 模糊匹配库
        fuzzy_income = ['收', '贷', '入', '存']
        fuzzy_expense = ['支', '借', '出', '取']
        
        unified_count = 0
        fuzzy_count = 0
        amount_based_count = 0
        
        for i, row in enumerate(rows):
            if len(row) > debit_credit_col:
                debit_credit_value = row[debit_credit_col]
                
                if debit_credit_value is not None:
                    # 转换为字符串并清理
                    value_str = str(debit_credit_value).strip()
                    
                    if value_str:
                        # 首先进行精准映射
                        if value_str in exact_mapping:
                            unified_value = exact_mapping[value_str]
                            if unified_value != value_str:
                                row[debit_credit_col] = unified_value
                                unified_count += 1
                                # 只记录前100行和最后100行的映射情况，避免日志过多
                                if i < 100 or i >= len(rows) - 100:
                                    self.logger.info(f"行 {i+1}: 精准映射借贷标志: {value_str} -> {unified_value}")
                                elif i == 100:
                                    self.logger.info(f"... 省略中间 {len(rows) - 200} 行的映射日志 ...")
                        else:
                            # 其次进行模糊匹配
                            matched = False
                            # 检查收入模糊匹配
                            for keyword in fuzzy_income:
                                if keyword in value_str:
                                    row[debit_credit_col] = '收入'
                                    fuzzy_count += 1
                                    # 只记录前100行和最后100行的映射情况，避免日志过多
                                    if i < 100 or i >= len(rows) - 100:
                                        self.logger.info(f"行 {i+1}: 模糊匹配借贷标志: {value_str} -> 收入")
                                    matched = True
                                    break
                            # 检查支出模糊匹配
                            if not matched:
                                for keyword in fuzzy_expense:
                                    if keyword in value_str:
                                        row[debit_credit_col] = '支出'
                                        fuzzy_count += 1
                                        # 只记录前100行和最后100行的映射情况，避免日志过多
                                        if i < 100 or i >= len(rows) - 100:
                                            self.logger.info(f"行 {i+1}: 模糊匹配借贷标志: {value_str} -> 支出")
                                        matched = True
                                        break
                else:
                    # 保持空白借贷标志不变，不进行推断
                    pass
        
        self.logger.info(f"统一了 {unified_count} 行借贷标志（精准映射）")
        self.logger.info(f"统一了 {fuzzy_count} 行借贷标志（模糊匹配）")
        return rows
    

    
    def extract_information(self, rows: List[List[Any]], headers: List[str], file_path: str, object_names=None) -> Tuple[List[List[Any]], List[str]]:
        """提取信息
        
        Args:
            rows: 数据行
            headers: 表头信息
            file_path: 文件路径，用于从文件名提取信息
            
        Returns:
            Tuple[List[List[Any]], List[str]]: (提取信息后的数据行, 更新后的表头)
        """
        import re
        from typing import Tuple
        
        # 复制表头，避免修改原始表头
        updated_headers = headers.copy()
        
        # 查找相关列的索引
        card_number_col = -1  # 银行卡号
        account_number_col = -1  # 账号
        bank_col = -1  # 开户行
        account_holder_col = -1  # 户主名称
        data_source_col = -1  # 数据来源
        
        # 列名关键词
        card_number_keywords = ['本方卡号']
        account_number_keywords = ['本方账号']
        bank_keywords = ['本方账户开户行']
        account_holder_keywords = ['户主名称']
        data_source_keywords = ['数据来源']
        
        # 查找列索引
        for i, header in enumerate(updated_headers):
            if any(keyword in header for keyword in card_number_keywords):
                card_number_col = i
            if any(keyword in header for keyword in account_number_keywords):
                account_number_col = i
            if any(keyword in header for keyword in bank_keywords):
                bank_col = i
            if any(keyword in header for keyword in account_holder_keywords):
                account_holder_col = i
            if any(keyword in header for keyword in data_source_keywords):
                data_source_col = i
        
        extracted_count = 0
        
        # 通用词汇列表，用于过滤
        common_words = ['流水', '账号', '卡号', '信息', '账单', '明细', '查询']
        
        # 处理每一行数据
        for i, row in enumerate(rows):
            # 检查数据来源列是否存在且有值
            if data_source_col == -1 or len(row) <= data_source_col or row[data_source_col] is None:
                continue
            
            # 获取数据来源列的路径字符串
            data_source = str(row[data_source_col])
            
            # 跳过非路径字符串
            if data_source in ['无', '手动录入']:
                continue
            
            # 解析路径字符串，提取最末2级
            path_parts = re.split(r'[\\/]', data_source)
            # 过滤空字符串
            path_parts = [part for part in path_parts if part.strip()]
            
            # 确定提取范围
            if len(path_parts) >= 2:
                # 取倒数第2段（目录）和倒数第1段（文件名）
                dir_part = path_parts[-2]
                file_part = path_parts[-1]
            else:
                # 路径层级不足2级，只取文件名
                dir_part = ''
                file_part = path_parts[-1] if path_parts else ''
            
            # 去除文件名后缀
            file_name_without_ext = os.path.splitext(file_part)[0]
            
            # 合并提取范围用于字段提取
            if dir_part:
                extract_range = f"{dir_part} {file_name_without_ext}"
            else:
                extract_range = file_name_without_ext
            
            # 1. 提取本方账号开户行
            bank_name = None
            
            # 辅助函数：排除对象名称
            def remove_object_names(text):
                if object_names:
                    result = text
                    # 按长度降序排序，优先排除长的对象名称
                    sorted_names = sorted(object_names, key=len, reverse=True)
                    for name in sorted_names:
                        if name in result:
                            # 只替换完整的连续字符串
                            result = result.replace(name, '')
                    return result
                return text
            
            # 优先从文件名部分提取
            if file_name_without_ext:
                # 排除对象名称
                cleaned_file_name = remove_object_names(file_name_without_ext)
                # 确保包含银行相关关键字且仅为连续汉字
                bank_match = re.search(r'[\u4e00-\u9fa5]*[银行|支行|分行|行|中心|信用社|总行|农商行|财付通|支付宝][\u4e00-\u9fa5]*', cleaned_file_name)
                if bank_match:
                    bank_name = bank_match.group()
            
            # 如果文件名部分没有找到，从目录部分提取
            if not bank_name and dir_part:
                # 排除对象名称
                cleaned_dir_part = remove_object_names(dir_part)
                # 确保包含银行相关关键字且仅为连续汉字
                bank_match = re.search(r'[\u4e00-\u9fa5]*[银行|支行|分行|行|中心|信用社|总行|农商行|财付通|支付宝][\u4e00-\u9fa5]*', cleaned_dir_part)
                if bank_match:
                    bank_name = bank_match.group()
            
            # 辅助函数：验证是否为合法身份证号
            def is_valid_id_card(id_card):
                """验证18位居民身份证号是否合法"""
                import re
                from datetime import datetime
                
                # 规则1：验证长度和字符格式
                if len(id_card) != 18:
                    return False
                # 前17位必须是数字，第18位是数字或X（大写）
                pattern = r'^\d{17}[\dX]$'
                if not re.match(pattern, id_card):
                    return False

                # 规则2：验证出生日期（7-14位）
                try:
                    birth_date_str = id_card[6:14]  # 提取7-14位：YYYYMMDD
                    # 解析日期，自动验证合法性（如19900230会报错）
                    birth_date = datetime.strptime(birth_date_str, '%Y%m%d')
                    # 额外验证：出生日期不能晚于当前日期
                    if birth_date > datetime.now():
                        return False
                except ValueError:
                    return False

                # 规则3：验证校验码（核心）
                # 权重数组
                weights = [7, 9, 10, 5, 8, 4, 2, 1, 6, 3, 7, 9, 10, 5, 8, 4, 2]
                # 余数对应的校验码
                check_codes = ['1', '0', 'X', '9', '8', '7', '6', '5', '4', '3', '2']
                
                # 计算前17位的加权和
                total = 0
                for i in range(17):
                    total += int(id_card[i]) * weights[i]
                # 计算余数
                remainder = total % 11
                # 计算应有的校验码
                expected_check_code = check_codes[remainder]
                # 对比实际校验码（转大写，兼容小写x）
                actual_check_code = id_card[-1].upper()
                
                return expected_check_code == actual_check_code
            
            # 辅助函数：从文本中提取指定长度范围的数字
            def extract_number(text, min_len, max_len):
                if not text:
                    return None
                number_matches = re.findall(r'\d+', text)
                # 过滤日期类数字（如20240310），只过滤长度正好为8的数字
                # 过滤身份证号
                valid_numbers = []
                for num in number_matches:
                    # 过滤日期类数字
                    if len(num) == 8 and re.match(r'\d{8}', num):
                        continue
                    # 过滤身份证号
                    if len(num) == 18 and is_valid_id_card(num):
                        continue
                    # 过滤长度小于4的数字
                    if len(num) >= 4:
                        valid_numbers.append(num)
                # 筛选指定长度范围的数字
                candidates = [num for num in valid_numbers if min_len <= len(num) <= max_len]
                if candidates:
                    # 优先提取最长的
                    return max(candidates, key=len)
                return None
            
            # 2. 提取本方账户（13-19位连续纯数字串）
            account_number = extract_number(file_name_without_ext, 13, 19)
            if not account_number and dir_part:
                account_number = extract_number(dir_part, 13, 19)
            
            # 3. 提取本方卡号（13-19位连续纯数字串）
            card_number = extract_number(file_name_without_ext, 13, 19)
            if not card_number and dir_part:
                card_number = extract_number(dir_part, 13, 19)
            
            # 4. 提取户主名称
            account_holder = None
            
            # 优先检查用户输入的对象名称
            file_matched_names = []
            dir_matched_names = []
            
            if object_names:
                # 检查文件名中是否包含用户输入的对象名称
                for name in object_names:
                    if name in file_name_without_ext:
                        file_matched_names.append(name)
                
                # 检查目录名中是否包含用户输入的对象名称
                for name in object_names:
                    if name in dir_part:
                        dir_matched_names.append(name)
                
                # 如果文件名中找到匹配的对象名称，优先使用
                if file_matched_names:
                    # 如果只匹配到一个名称，使用该名称
                    if len(file_matched_names) == 1:
                        account_holder = file_matched_names[0]
                        self.logger.info(f"从文件名中优先提取用户输入的对象名称: {account_holder}")
                    # 如果匹配到多个名称，跳过提取
                    else:
                        self.logger.info(f"文件名中匹配到多个用户输入的对象名称，跳过提取")
                # 如果文件名中没有找到，但目录名中找到且只找到一个，使用该名称
                elif dir_matched_names and len(dir_matched_names) == 1:
                    account_holder = dir_matched_names[0]
                    self.logger.info(f"从目录名中优先提取用户输入的对象名称: {account_holder}")
                # 如果目录名中也匹配到多个名称，跳过提取
                elif dir_matched_names and len(dir_matched_names) > 1:
                    self.logger.info(f"目录名中匹配到多个用户输入的对象名称，跳过提取")
            
            # 如果没有匹配到用户输入的对象名称，使用原有逻辑提取
            if not account_holder:
                # 常见姓氏列表
                common_surnames = ['赵', '钱', '孙', '李', '周', '吴', '郑', '王', '冯', '陈', '褚', '卫', '蒋', '沈', '韩', '杨',
                '朱', '秦', '尤', '许', '何', '吕', '施', '张', '孔', '曹', '严', '华', '金', '魏', '陶', '姜',
                '戚', '谢', '邹', '喻', '柏', '水', '窦', '章', '云', '苏', '潘', '葛', '奚', '范', '彭', '郎',
                '鲁', '韦', '昌', '马', '苗', '凤', '花', '方', '俞', '任', '袁', '柳', '酆', '鲍', '史', '唐',
                '费', '廉', '岑', '薛', '雷', '贺', '倪', '汤', '滕', '殷', '罗', '毕', '郝', '邬', '安', '常',
                '乐', '于', '时', '傅', '皮', '卞', '齐', '康', '伍', '余', '元', '卜', '顾', '孟', '平', '黄',
                '穆', '萧', '尹', '姚', '邵', '湛', '汪', '祁', '毛', '禹', '狄', '米', '贝', '明', '臧',
                '计', '伏', '成', '戴', '谈', '宋', '茅', '庞', '熊', '纪', '舒', '屈', '项', '祝', '董', '梁',
                '杜', '阮', '蓝', '闵', '席', '季', '麻', '贾', '路', '娄', '危', '江', '童', '颜', '郭',
                '梅', '盛', '林', '刁', '钟', '徐', '邱', '骆', '高', '夏', '蔡', '田', '樊', '胡', '凌', '霍',
                '虞', '万', '支', '柯', '昝', '管', '卢', '莫', '房', '裘', '缪', '干', '解', '应', '宗',
                '丁', '宣', '贲', '邓', '郁', '单', '杭', '洪', '包', '诸', '左', '石', '崔', '吉', '钮', '龚',
                '程', '嵇', '邢', '滑', '裴', '陆', '荣', '翁', '荀', '羊', '于', '惠', '甄', '曲', '封',
                '芮', '羿', '储', '靳', '汲', '邴', '糜', '松', '井', '段', '富', '巫', '乌', '焦', '巴', '弓',
                '牧', '隗', '谷', '车', '侯', '宓', '蓬', '郗', '仰', '秋', '仲', '伊', '宫',
                '宁', '仇', '栾', '暴', '甘', '钭', '厉', '戎', '祖', '武', '符', '刘', '景', '詹', '束', '龙',
                '叶', '幸', '司', '韶', '郜', '黎', '蓟', '薄', '印', '宿', '白', '怀', '蒲', '邰', '从', '鄂',
                '索', '咸', '籍', '赖', '卓', '蔺', '屠', '蒙', '池', '乔', '阴', '郁', '胥', '能', '苍',
                '闻', '莘', '翟', '谭', '贡', '劳', '逄', '姬', '申', '扶', '堵', '冉', '宰', '郦', '雍',
                '璩', '桑', '桂', '濮', '牛', '寿', '扈', '燕', '冀', '郏', '浦', '尚',
                '温', '庄', '晏', '柴', '瞿', '阎', '充', '慕', '连', '茹', '习', '宦', '艾', '容',
                '向', '古', '易', '慎', '戈', '廖', '庾', '终', '暨', '居', '衡', '步', '都', '耿', '满', '弘',
                '匡', '文', '寇', '禄', '阙', '欧', '殳', '沃', '利', '蔚', '越', '夔', '隆',
                '师', '巩', '厍', '聂', '晁', '勾', '敖', '融', '冷', '訾', '辛', '阚', '简', '饶', '涂',
                '曾', '毋', '沙', '乜', '养', '鞠', '须', '丰', '巢', '关', '蒯', '相', '查', '后', '荆',
                '游', '竺', '逯', '盖', '益', '桓', '万俟', '司马', '上官', '欧阳', '夏侯', '诸葛',
                '闻人', '赫连', '皇甫', '尉迟', '公羊', '澹台', '申屠', '太叔', '轩辕', '令狐', '钟离',
                '宇文', '长孙', '慕容', '司寇', '仲孙']
                
                # 排除词库
                exclude_words = ['纪检', '纪监', '查询', '蓝图', '双方', '计算', '计划', '强化', '方向', '方面', '成功', '高等', '高级', '万元', '单独', '单元', '单向', '房屋', '房产', '房地产', '包括', '包围', '程序', '程度', '明细', '明细对私',
                                 '账户', '帐户', '帐号', '账号',
                                # 常见银行名称，避免提取到流水提供单位
                                '中国工商银行', '工商银行', '中国建设银行', '建设银行', '中国农业银行', '农业银行', '中国银行', '交通银行', '中国邮政储蓄银行', '邮政储蓄银行',
                                '招商银行', '中信银行', '光大银行', '浦发银行', '民生银行', '平安银行', '华夏银行', '兴业银行', '广发银行',
                                '渤海银行', '恒丰银行', '浙商银行', '北京银行', '上海银行', '南京银行', '宁波银行', '江苏银行', '杭州银行',
                                '成都银行', '西安银行', '长沙银行', '广州银行', '深圳银行', '青岛银行', '大连银行', '哈尔滨银行', '合肥银行',
                                '昆明银行', '贵阳银行', '南宁银行', '南昌银行', '太原银行', '石家庄银行', '乌鲁木齐银行', '兰州银行', '西宁银行',
                                '银川银行', '拉萨银行']
                
                # 常见后缀词库
                suffix_words = ['账单', '账户', '帐户', '帐号', '账号', '流水', '信息', '银行流水', '交易信息', '交易流水', '流水信息', '信用卡', '交易记录', '明细', '明细对私']
                
                # 辅助函数：检测文本中是否包含多个姓氏且之间有特定符号
                def has_multiple_surnames_with_symbols(text):
                    # 检测文本中包含的姓氏
                    surnames_found = []
                    for surname in common_surnames:
                        if surname in text:
                            surnames_found.append(surname)
                    
                    # 如果找到多个姓氏
                    if len(surnames_found) >= 2:
                        # 检测姓氏之间是否存在特定符号
                        symbols = [' ', '，', '、', ',', '\t', '/', '\\', '-', '——', '.']
                        for i in range(len(surnames_found) - 1):
                            # 查找两个姓氏在文本中的位置
                            pos1 = text.find(surnames_found[i])
                            pos2 = text.find(surnames_found[i+1])
                            if pos1 != -1 and pos2 != -1 and pos1 < pos2:
                                # 检查两个姓氏之间是否有特定符号
                                between = text[pos1 + len(surnames_found[i]):pos2]
                                if any(symbol in between for symbol in symbols):
                                    return True
                    return False
                
                # 辅助函数：提取人名
                def extract_person_name(text):
                    # 常见非人名前缀
                    non_name_prefixes = ['纪监', '纪检', '查询', '电网', '银行', '流水', '交易', '信息', '记录', '明细',
                                        # 银行相关前缀
                                        '中国工商银行', '工商银行', '中国建设银行', '建设银行', '中国农业银行', '农业银行', '中国银行', '交通银行',
                                        '中国邮政储蓄银行', '邮政储蓄银行', '招商银行', '中信银行', '光大银行', '浦发银行', '民生银行', '平安银行',
                                        '华夏银行', '兴业银行', '广发银行']
                    
                    # 分割文本为单词，尝试从每个单词中提取人名
                    # 优先处理最后一个单词，因为人名通常在文件名的末尾
                    words = re.split(r'[-_\s\(\)\[\]{}]+', text)
                    # 逆序处理，优先考虑末尾的单词
                    for word in reversed(words):
                        # 提取连续汉字字符串
                        word_chinese = re.findall(r'[\u4e00-\u9fa5]+', word)
                        for string in word_chinese:
                            # 跳过常见非人名前缀
                            skip = False
                            for prefix in non_name_prefixes:
                                if string.startswith(prefix):
                                    skip = True
                                    break
                            if skip:
                                continue
                            
                            # 先去除常见前缀
                            for prefix in ['账单', '银行', '流水', '交易', '信息', '记录', '明细']:
                                if string.startswith(prefix):
                                    string = string[len(prefix):]
                            
                            # 检查前缀存在姓氏的情况，且长度在2-4个汉字之间
                            if 2 <= len(string) <= 4 and string[0] in common_surnames:
                                # 去除后缀（长后缀优先）
                                for suffix in sorted(suffix_words, key=len, reverse=True):
                                    if string.endswith(suffix):
                                        string = string[:-len(suffix)]
                                # 确保剩余部分长度合理
                                if 2 <= len(string) <= 4:
                                    return string
                    
                    # 如果上面的方法没有找到，尝试从整个文本中提取
                    chinese_strings = re.findall(r'[\u4e00-\u9fa5]+', text)
                    for string in chinese_strings:
                        # 跳过常见非人名前缀
                        skip = False
                        for prefix in non_name_prefixes:
                            if string.startswith(prefix):
                                skip = True
                                break
                        if skip:
                            continue
                        
                        # 先去除常见前缀
                        for prefix in ['账单', '银行', '流水', '交易', '信息', '记录', '明细']:
                            if string.startswith(prefix):
                                string = string[len(prefix):]
                        
                        # 检查前缀存在姓氏的情况，且长度在2-4个汉字之间
                        if 2 <= len(string) <= 4 and string[0] in common_surnames:
                            # 去除后缀（长后缀优先）
                            for suffix in sorted(suffix_words, key=len, reverse=True):
                                if string.endswith(suffix):
                                    string = string[:-len(suffix)]
                            # 确保剩余部分长度合理
                            if 2 <= len(string) <= 4:
                                return string
                        
                        # 检查整个字符串中是否有姓氏，且长度在2-4个汉字之间
                        for i in range(len(string)):
                            if string[i] in common_surnames and i + 1 < len(string):
                                # 提取从姓氏开始的部分
                                candidate = string[i:]
                                # 去除后缀（长后缀优先）
                                for suffix in sorted(suffix_words, key=len, reverse=True):
                                    if candidate.endswith(suffix):
                                        candidate = candidate[:-len(suffix)]
                                # 确保剩余部分长度合理
                                if 2 <= len(candidate) <= 4:
                                    return candidate
                    return None
                
                # 辅助函数：提取公司名
                def extract_company_name(text):
                    company_suffixes = ['有限责任公司', '公司', '集团', '商行']
                    
                    for suffix in company_suffixes:
                        # 查找后缀在字符串中的位置
                        suffix_pos = text.find(suffix)
                        if suffix_pos != -1:
                            # 从后缀位置向前查找公司名的开始
                            # 尝试找到一个合理的公司名开始位置
                            # 跳过前面可能的人名
                            start_pos = 0
                            
                            # 首先检查是否有明确的公司名前缀
                            # 常见的公司名前缀
                            company_prefixes = self.COMPANY_PREFIXES
                            
                            # 从后缀位置向前搜索，寻找公司名前缀
                            # 遍历所有可能的前缀位置
                            found_prefix = False
                            for prefix in company_prefixes:
                                prefix_pos = text.find(prefix)
                                if prefix_pos != -1 and prefix_pos < suffix_pos:
                                    start_pos = prefix_pos
                                    found_prefix = True
                                    break
                            
                            # 如果没有找到公司名前缀，尝试从字符串开头开始提取
                            if not found_prefix:
                                # 从字符串开头到后缀位置提取
                                # 但要跳过前面可能的人名
                                for i in range(suffix_pos):
                                    # 检查从i到suffix_pos是否可能是公司名
                                    candidate = text[i:suffix_pos + len(suffix)]
                                    # 检查是否包含常见的公司名关键词
                                    if any(keyword in candidate for keyword in ['科技', '贸易', '实业', '投资', '集团', '有限公司']):
                                        start_pos = i
                                        break
                                
                                # 如果没有找到公司名关键词，尝试跳过前面的人名
                                if start_pos == 0:
                                    # 从后缀位置向前搜索，找到可能的公司名开始
                                    # 尝试找到连续的汉字和字母作为公司名
                                    for i in range(suffix_pos, -1, -1):
                                        # 如果遇到非汉字和字母的字符，停止
                                        if not ('\u4e00' <= text[i] <= '\u9fa5' or 'a' <= text[i].lower() <= 'z'):
                                            start_pos = i + 1
                                            break
                                        # 检查是否可能是人名（2-4个汉字，以姓氏开头）
                                        if i > 0 and (suffix_pos - i + 1) <= 4:
                                            # 检查前面的字符是否可能是人名
                                            candidate = text[i:suffix_pos + len(suffix)]
                                            # 如果候选字符串以姓氏开头且长度为2-4，可能是人名，继续向前搜索
                                            if len(candidate) >= 2 and len(candidate) <= 4 and candidate[0] in common_surnames:
                                                # 跳过这个人名，从前面开始搜索
                                                start_pos = i - 1
                                                break
                            
                            # 提取公司名
                            company_name = text[start_pos:suffix_pos + len(suffix)]
                            # 确保公司名长度合理
                            # 检查是否包含银行相关关键词
                            bank_keywords = ['银行', '支行', '分行', '营业部', '分理处', '行', '中心', '信用社', '总行', '农商行', '财付通', '支付宝']
                            has_bank_keyword = any(keyword in company_name for keyword in bank_keywords)
                            if len(company_name) >= 2 and not any(word in company_name for word in exclude_words) and not has_bank_keyword:
                                return company_name
                    return None
                
                # 优先从文件名提取户主名称
                if file_name_without_ext:
                    # 检查文件名是否包含多个姓氏且有特定符号
                    if not has_multiple_surnames_with_symbols(file_name_without_ext):
                        # 先尝试提取人名（优先于公司名）
                        person_name = extract_person_name(file_name_without_ext)
                        if person_name and not any(word in person_name for word in exclude_words):
                            account_holder = person_name
                        else:
                            # 尝试提取公司名
                            company_name = extract_company_name(file_name_without_ext)
                            if company_name:
                                account_holder = company_name
                
                # 如果文件名中没有找到，从目录提取
                if not account_holder and dir_part:
                    # 检查目录是否包含多个姓氏且有特定符号
                    if not has_multiple_surnames_with_symbols(dir_part):
                        # 先尝试提取人名（优先于公司名）
                        person_name = extract_person_name(dir_part)
                        if person_name and not any(word in person_name for word in exclude_words):
                            account_holder = person_name
                        else:
                            # 尝试提取公司名
                            company_name = extract_company_name(dir_part)
                            if company_name:
                                account_holder = company_name
            

            
            # 确保行长度足够
            max_col = max(bank_col, account_holder_col, account_number_col, card_number_col)
            if max_col >= len(row):
                row.extend([None] * (max_col - len(row) + 1))
            
            # 将提取结果写入对应列
            if bank_col != -1 and row[bank_col] is None and bank_name:
                row[bank_col] = bank_name
                extracted_count += 1
                # 只记录前100行和最后100行的提取情况，避免日志过多
                if i < 100 or i >= len(rows) - 100:
                    self.logger.info(f"行 {i+1}: 提取开户行: {bank_name}")
            
            if account_holder_col != -1 and row[account_holder_col] is None and account_holder:
                row[account_holder_col] = account_holder
                extracted_count += 1
                # 只记录前100行和最后100行的提取情况，避免日志过多
                if i < 100 or i >= len(rows) - 100:
                    self.logger.info(f"行 {i+1}: 提取户主名称: {account_holder}")
            
            if account_number_col != -1 and row[account_number_col] is None and account_number:
                row[account_number_col] = account_number
                extracted_count += 1
                # 只记录前100行和最后100行的提取情况，避免日志过多
                if i < 100 or i >= len(rows) - 100:
                    self.logger.info(f"行 {i+1}: 提取账号: {account_number}")
            
            if card_number_col != -1 and row[card_number_col] is None and card_number:
                row[card_number_col] = card_number
                extracted_count += 1
                # 只记录前100行和最后100行的提取情况，避免日志过多
                if i < 100 or i >= len(rows) - 100:
                    self.logger.info(f"行 {i+1}: 提取银行卡号: {card_number}")
        
        self.logger.info(f"提取了 {extracted_count} 条信息")
        return rows, updated_headers
    

    
    def match_account_holder(self, rows: List[List[Any]], headers: List[str]) -> Tuple[List[List[Any]], List[int]]:
        """根据户主名称、交易对方名称、本方账号或银行卡号匹配缺失的字段
        
        Args:
            rows: 数据行
            headers: 表头信息
            
        Returns:
            Tuple[List[List[Any]], List[int]]: (匹配后的行数据, 被匹配的行索引列表)
        """
        # 查找相关列的索引
        account_holder_col = -1  # 户主名称
        card_number_col = -1  # 本方卡号
        account_number_col = -1  # 本方账号
        counterparty_name_col = -1  # 交易对方名称
        counterparty_card_col = -1  # 交易对方卡号
        counterparty_account_col = -1  # 交易对方账号
        
        # 列名关键词
        account_holder_keywords = ['户主名称']
        card_number_keywords = ['本方卡号']
        account_number_keywords = ['本方账号']
        counterparty_name_keywords = ['交易对方名称']
        counterparty_card_keywords = ['交易对方卡号']
        counterparty_account_keywords = ['交易对方账号']
        
        # 查找列索引
        for i, header in enumerate(headers):
            if any(keyword in header for keyword in account_holder_keywords):
                account_holder_col = i
            elif any(keyword in header for keyword in card_number_keywords):
                card_number_col = i
            elif any(keyword in header for keyword in account_number_keywords):
                account_number_col = i
            elif any(keyword in header for keyword in counterparty_name_keywords):
                counterparty_name_col = i
            elif any(keyword in header for keyword in counterparty_card_keywords):
                counterparty_card_col = i
            elif any(keyword in header for keyword in counterparty_account_keywords):
                counterparty_account_col = i
        
        # 构建映射表
        # 格式: {key: value}，其中key是卡号/账号，value是对应的名称
        # 注意：我们使用一个统一的映射表，因为卡号/账号在不同角色中可能是相同的
        name_mapping = {}  # 卡号/账号到名称的统一映射
        
        # 首先收集所有可能的映射关系
        for row in rows:
            # 1. 从有户主名称的行中收集映射
            if account_holder_col != -1 and len(row) > account_holder_col:
                holder = row[account_holder_col]
                if holder is not None and (isinstance(holder, str) and holder.strip()):
                    # 优先使用本方卡号作为键
                    if card_number_col != -1 and len(row) > card_number_col:
                        card = row[card_number_col]
                        if card is not None and (isinstance(card, str) and card.strip()):
                            card_key = card.strip()
                            if card_key not in name_mapping:
                                name_mapping[card_key] = holder
                    # 再使用本方账号作为键
                    if account_number_col != -1 and len(row) > account_number_col:
                        account = row[account_number_col]
                        if account is not None and (isinstance(account, str) and account.strip()):
                            account_key = account.strip()
                            if account_key not in name_mapping:
                                name_mapping[account_key] = holder
            
            # 2. 从有交易对方名称的行中收集映射
            if counterparty_name_col != -1 and len(row) > counterparty_name_col:
                counterparty = row[counterparty_name_col]
                if counterparty is not None and (isinstance(counterparty, str) and counterparty.strip()):
                    # 优先使用交易对方卡号作为键
                    if counterparty_card_col != -1 and len(row) > counterparty_card_col:
                        card = row[counterparty_card_col]
                        if card is not None and (isinstance(card, str) and card.strip()):
                            card_key = card.strip()
                            if card_key not in name_mapping:
                                name_mapping[card_key] = counterparty
                    # 再使用交易对方账号作为键
                    if counterparty_account_col != -1 and len(row) > counterparty_account_col:
                        account = row[counterparty_account_col]
                        if account is not None and (isinstance(account, str) and account.strip()):
                            account_key = account.strip()
                            if account_key not in name_mapping:
                                name_mapping[account_key] = counterparty
        
        # 匹配缺失的字段
        matched_count = 0
        matched_rows = []
        
        # 遍历所有行，进行匹配
        for i, row in enumerate(rows):
            # 1. 匹配缺失的户主名称
            if account_holder_col != -1 and len(row) > account_holder_col:
                holder = row[account_holder_col]
                if holder is None or (isinstance(holder, str) and not holder.strip()):
                    # 优先匹配本方卡号
                    card_matched = False
                    if card_number_col != -1 and len(row) > card_number_col:
                        card = row[card_number_col]
                        if card is not None and (isinstance(card, str) and card.strip()):
                            card_key = card.strip()
                            if card_key in name_mapping:
                                row[account_holder_col] = name_mapping[card_key]
                                matched_count += 1
                                matched_rows.append(i)
                                card_matched = True
                                # 只记录前100行和最后100行的匹配情况，避免日志过多
                                if i < 100 or i >= len(rows) - 100:
                                    self.logger.info(f"根据本方卡号匹配户主名称: {card_key} -> {name_mapping[card_key]}")
                    # 再匹配本方账号
                    if not card_matched and account_number_col != -1 and len(row) > account_number_col:
                        account = row[account_number_col]
                        if account is not None and (isinstance(account, str) and account.strip()):
                            account_key = account.strip()
                            if account_key in name_mapping:
                                row[account_holder_col] = name_mapping[account_key]
                                matched_count += 1
                                matched_rows.append(i)
                                # 只记录前100行和最后100行的匹配情况，避免日志过多
                                if i < 100 or i >= len(rows) - 100:
                                    self.logger.info(f"根据本方账号匹配户主名称: {account_key} -> {name_mapping[account_key]}")
            
            # 2. 匹配缺失的交易对方名称
            if counterparty_name_col != -1 and len(row) > counterparty_name_col:
                counterparty = row[counterparty_name_col]
                if counterparty is None or (isinstance(counterparty, str) and not counterparty.strip()):
                    # 优先匹配交易对方卡号
                    card_matched = False
                    if counterparty_card_col != -1 and len(row) > counterparty_card_col:
                        card = row[counterparty_card_col]
                        if card is not None and (isinstance(card, str) and card.strip()):
                            card_key = card.strip()
                            if card_key in name_mapping:
                                row[counterparty_name_col] = name_mapping[card_key]
                                matched_count += 1
                                matched_rows.append(i)
                                card_matched = True
                                # 只记录前100行和最后100行的匹配情况，避免日志过多
                                if i < 100 or i >= len(rows) - 100:
                                    self.logger.info(f"根据交易对方卡号匹配交易对方名称: {card_key} -> {name_mapping[card_key]}")
                    # 再匹配交易对方账号
                    if not card_matched and counterparty_account_col != -1 and len(row) > counterparty_account_col:
                        account = row[counterparty_account_col]
                        if account is not None and (isinstance(account, str) and account.strip()):
                            account_key = account.strip()
                            if account_key in name_mapping:
                                row[counterparty_name_col] = name_mapping[account_key]
                                matched_count += 1
                                matched_rows.append(i)
                                # 只记录前100行和最后100行的匹配情况，避免日志过多
                                if i < 100 or i >= len(rows) - 100:
                                    self.logger.info(f"根据交易对方账号匹配交易对方名称: {account_key} -> {name_mapping[account_key]}")
        
        self.logger.info(f"匹配了 {matched_count} 行数据")
        return rows, matched_rows
    
    def remove_zero_amount_rows(self, rows: List[List[Any]], headers: List[str]) -> List[List[Any]]:
        """删除交易金额为0的整行数据
        
        Args:
            rows: 数据行
            headers: 表头信息
            
        Returns:
            List[List[Any]]: 删除后的行数据
        """
        import re
        
        # 查找交易金额列的索引
        amount_col = -1
        amount_keywords = [
            '交易金额'
        ]
        
        for i, header in enumerate(headers):
            if any(keyword in header for keyword in amount_keywords):
                amount_col = i
                break
        
        if amount_col == -1:
            self.logger.info("未找到交易金额列，跳过删除交易金额为0的行")
            return rows
        
        cleaned_rows = []
        zero_amount_count = 0
        
        for row in rows:
            if len(row) > amount_col:
                amount_value = row[amount_col]
                
                # 检查金额是否为0
                if amount_value is not None:
                    if isinstance(amount_value, (int, float)):
                        if amount_value == 0:
                            zero_amount_count += 1
                            continue
                    elif isinstance(amount_value, str):
                        # 清理金额字符串
                        cleaned_amount = re.sub(r'[￥$¥,]', '', amount_value.strip())
                        try:
                            amount_num = float(cleaned_amount)
                            if amount_num == 0:
                                zero_amount_count += 1
                                continue
                        except:
                            pass
            
            cleaned_rows.append(row)
        
        self.logger.info(f"删除了 {zero_amount_count} 行交易金额为0的数据")
        return cleaned_rows
    
    def remove_zero_card_account_rows(self, rows: List[List[Any]], headers: List[str]) -> List[List[Any]]:
        """删除本方卡号、本方账号为全0的整行数据
        
        Args:
            rows: 数据行
            headers: 表头信息
            
        Returns:
            List[List[Any]]: 删除后的行数据
        """
        # 查找卡号和账号列的索引
        card_number_col = -1  # 银行卡号
        account_number_col = -1  # 账号
        
        # 列名关键词
        card_number_keywords = ['本方卡号']
        account_number_keywords = ['本方账号']

        # 查找列索引
        for i, header in enumerate(headers):
            if any(keyword in header for keyword in card_number_keywords):
                card_number_col = i
            if any(keyword in header for keyword in account_number_keywords):
                account_number_col = i
        
        if card_number_col == -1 and account_number_col == -1:
            self.logger.info("未找到卡号或账号列，跳过删除全0的卡号和账号行")
            return rows
        
        cleaned_rows = []
        zero_count = 0
        
        for row in rows:
            is_zero_card = False
            is_zero_account = False
            
            # 检查卡号是否为全0
            if card_number_col != -1 and len(row) > card_number_col:
                card_value = row[card_number_col]
                if card_value is not None:
                    card_str = str(card_value).strip()
                    # 检查是否为全0
                    if card_str and all(c == '0' for c in card_str):
                        is_zero_card = True
            
            # 检查账号是否为全0
            if account_number_col != -1 and len(row) > account_number_col:
                account_value = row[account_number_col]
                if account_value is not None:
                    account_str = str(account_value).strip()
                    # 检查是否为全0
                    if account_str and all(c == '0' for c in account_str):
                        is_zero_account = True
            
            # 如果卡号或账号为全0，删除该行
            if is_zero_card or is_zero_account:
                zero_count += 1
                continue
            
            cleaned_rows.append(row)
        
        self.logger.info(f"删除了 {zero_count} 行卡号或账号为全0的数据")
        return cleaned_rows
    

