#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
日期时间处理模块
负责日期时间的标准化、验证和处理
"""

import logging
import re
import datetime
from typing import List, Any, Tuple
from config import Config

class DateTimeProcessor:
    """日期时间处理器"""
    
    def __init__(self):
        """初始化"""
        self.logger = logging.getLogger(__name__)
        # 从配置文件获取日期时间格式
        self.date_formats = Config.DATE_TIME_FORMATS['date']
        self.time_formats = Config.DATE_TIME_FORMATS['time']
        self.datetime_formats = Config.DATE_TIME_FORMATS['datetime']
        # 默认日期阈值
        self.min_year = 1990
    
    def normalize_datetime_columns(self, rows: List[List[Any]], headers: List[str]) -> List[List[Any]]:
        """处理日期和时间列的关系
        
        Args:
            rows: 数据行
            headers: 表头信息
            
        Returns:
            List[List[Any]]: 处理后的数据行
        """
        # 查找日期和时间列的索引
        date_col = -1
        time_col = -1
        
        for i, header in enumerate(headers):
            if any(keyword in header for keyword in ['交易日期']):
                date_col = i
            elif any(keyword in header for keyword in ['交易时间']):
                time_col = i
        
        if date_col == -1 or time_col == -1:
            self.logger.info("未找到日期或时间列，跳过日期时间标准化")
            return rows
        
        normalized_count = 0
        
        for i, row in enumerate(rows):
            # 处理日期列
            if len(row) > date_col:
                date_value = row[date_col]
                if date_value is not None:
                    date_str = str(date_value).strip()
                    if date_str:
                        # 尝试使用配置的日期时间格式进行解析
                        parsed = False
                        dt = None
                        
                        # 尝试所有日期时间格式
                        for fmt_info in self.datetime_formats + self.date_formats:
                            try:
                                if re.match(fmt_info['pattern'], date_str):
                                    dt = datetime.datetime.strptime(date_str, fmt_info['format'])
                                    parsed = True
                                    break
                            except:
                                continue
                        
                        # 特殊处理14位数字时间格式（包括浮点数形式）
                        if not parsed:
                            # 检查是否为浮点数形式的14位数字
                            if '.' in date_str:
                                try:
                                    # 尝试转换为整数
                                    int_value = int(float(date_str))
                                    value_str = str(int_value)
                                    if len(value_str) == 14 and value_str.isdigit():
                                        dt = datetime.datetime.strptime(value_str, '%Y%m%d%H%M%S')
                                        parsed = True
                                except:
                                    pass
                            # 检查是否为字符串形式的14位数字
                            elif len(date_str) == 14 and date_str.isdigit():
                                try:
                                    dt = datetime.datetime.strptime(date_str, '%Y%m%d%H%M%S')
                                    parsed = True
                                except:
                                    pass
                        
                        if parsed:
                            # 检查时间列是否为空
                            time_empty = True
                            if len(row) > time_col:
                                time_value = row[time_col]
                                if time_value is not None:
                                    time_str = str(time_value).strip()
                                    if time_str:
                                        time_empty = False
                            
                            # 处理时分秒信息
                            if ' ' in date_str or 'T' in date_str or len(date_str) == 14:
                                if time_empty:
                                    # 时间列为空，将时分秒信息放入时间列
                                    if len(row) > time_col:
                                        row[time_col] = dt.strftime('%H:%M:%S')
                                    else:
                                        # 扩展行长度
                                        while len(row) <= time_col:
                                            row.append(None)
                                        row[time_col] = dt.strftime('%H:%M:%S')
                                    normalized_count += 1
                                    self.logger.info(f"行 {i+1}: 将日期中的时分秒信息放入时间列: {dt.strftime('%H:%M:%S')}")
                            
                            # 无论时间列是否为空，都更新日期列为只包含日期
                            row[date_col] = dt.strftime('%Y-%m-%d')
                            normalized_count += 1
                            self.logger.info(f"行 {i+1}: 标准化日期: {date_str} -> {dt.strftime('%Y-%m-%d')}")
            
            # 处理时间列
            if len(row) > time_col:
                time_value = row[time_col]
                if time_value is not None:
                    time_str = str(time_value).strip()
                    if time_str:
                        # 尝试使用配置的时间格式进行解析
                        parsed = False
                        dt = None
                        
                        # 特殊处理14位数字时间戳格式
                        if not parsed:
                            # 检查是否为浮点数形式的14位数字
                            if '.' in time_str:
                                try:
                                    # 尝试转换为整数
                                    int_value = int(float(time_str))
                                    value_str = str(int_value)
                                    if len(value_str) == 14 and value_str.isdigit():
                                        dt = datetime.datetime.strptime(value_str, '%Y%m%d%H%M%S')
                                        parsed = True
                                except:
                                    pass
                            # 检查是否为字符串形式的14位数字
                            elif len(time_str) == 14 and time_str.isdigit():
                                try:
                                    dt = datetime.datetime.strptime(time_str, '%Y%m%d%H%M%S')
                                    parsed = True
                                except:
                                    pass
                        
                        # 尝试使用配置的时间格式进行解析
                        if not parsed:
                            for fmt_info in self.time_formats:
                                try:
                                    if re.match(fmt_info['pattern'], time_str):
                                        dt = datetime.datetime.strptime(time_str, fmt_info['format'])
                                        parsed = True
                                        break
                                except:
                                    continue
                        
                        if parsed:
                            # 确保时间格式为完整的日期时间格式 YYYY-MM-DD HH:MM:SS
                            if len(time_str) == 14 or ('.' in time_str and len(time_str.split('.')[0]) == 14):
                                # 对于14位数字时间戳，直接格式化为完整的日期时间
                                full_datetime_str = dt.strftime('%Y-%m-%d %H:%M:%S')
                                row[time_col] = full_datetime_str
                                normalized_count += 1
                                self.logger.info(f"行 {i+1}: 标准化时间: {time_str} -> {full_datetime_str}")
                            else:
                                # 对于普通时间格式，保持原有处理
                                time_str = dt.strftime('%H:%M:%S')
                                row[time_col] = time_str
                                normalized_count += 1
                                self.logger.info(f"行 {i+1}: 标准化时间: {time_str} -> {time_str}")
        
        self.logger.info(f"标准化了 {normalized_count} 行日期时间数据")
        return rows
    
    def merge_datetime_columns(self, rows: List[List[Any]], headers: List[str]) -> Tuple[List[List[Any]], List[str]]:
        """合并日期和时间列
        
        Args:
            rows: 数据行
            headers: 表头信息
            
        Returns:
            Tuple[List[List[Any]], List[str]]: (处理后的数据行, 更新后的表头)
        """
        # 查找日期和时间列的索引
        date_col = -1
        time_col = -1
        
        for i, header in enumerate(headers):
            if any(keyword in header for keyword in ['交易日期']):
                date_col = i
            elif any(keyword in header for keyword in ['交易时间']):
                time_col = i
        
        if date_col == -1 or time_col == -1:
            self.logger.info("未找到日期或时间列，跳过日期时间合并")
            return rows, headers
        
        merged_count = 0
        deleted_count = 0
        filtered_rows = []
        
        for i, row in enumerate(rows):
            # 确保行长度足够
            if len(row) <= max(date_col, time_col):
                # 扩展行长度
                while len(row) <= max(date_col, time_col):
                    row.append(None)
                # 即使行长度不足，也保留该行
                filtered_rows.append(row)
                continue
            
            # 获取日期和时间值
            date_value = row[date_col]
            time_value = row[time_col]
            
            if date_value is None:
                # 日期为空，保留该行
                filtered_rows.append(row)
                continue
            
            # 解析日期
            date_str = str(date_value).strip()
            time_str = str(time_value).strip() if time_value is not None else ""
            
            # 尝试解析日期
            try:
                # 使用配置文件中定义的日期格式进行解析
                parsed_date = None
                
                for fmt_info in self.date_formats + self.datetime_formats:
                    try:
                        if re.match(fmt_info['pattern'], date_str):
                            parsed_date = datetime.datetime.strptime(date_str, fmt_info['format'])
                            break
                    except:
                        continue
                
                # 特殊处理14位数字时间格式（包括浮点数形式）
                if not parsed_date:
                    # 检查是否为浮点数形式的14位数字
                    if '.' in date_str:
                        try:
                            # 尝试转换为整数
                            int_value = int(float(date_str))
                            value_str = str(int_value)
                            if len(value_str) == 14 and value_str.isdigit():
                                parsed_date = datetime.datetime.strptime(value_str, '%Y%m%d%H%M%S')
                        except:
                            pass
                    # 检查是否为字符串形式的14位数字
                    elif len(date_str) == 14 and date_str.isdigit():
                        try:
                            parsed_date = datetime.datetime.strptime(date_str, '%Y%m%d%H%M%S')
                        except:
                            pass
                
                if not parsed_date:
                    # 日期解析失败，保留该行
                    filtered_rows.append(row)
                    continue
                
                # 检查日期是否在合理范围内（1990年至当前年份）
                current_year = datetime.datetime.now().year
                if parsed_date.year < self.min_year or parsed_date.year > current_year:
                    deleted_count += 1
                    if parsed_date.year < self.min_year:
                        self.logger.info(f"行 {i+1}: 日期 {parsed_date.strftime('%Y-%m-%d')} 在{self.min_year}年之前，删除整行")
                    else:
                        self.logger.info(f"行 {i+1}: 日期 {parsed_date.strftime('%Y-%m-%d')} 在{current_year}年之后，删除整行")
                    continue
                
                # 解析时间
                parsed_time = None
                if time_str:
                    # 使用配置文件中定义的时间格式进行解析
                    for fmt_info in self.time_formats:
                        try:
                            if re.match(fmt_info['pattern'], time_str):
                                parsed_time = datetime.datetime.strptime(time_str, fmt_info['format'])
                                break
                        except:
                            continue
                
                # 合并日期和时间
                if parsed_time:
                    merged_datetime = datetime.datetime(
                        parsed_date.year, parsed_date.month, parsed_date.day,
                        parsed_time.hour, parsed_time.minute, parsed_time.second
                    )
                else:
                    merged_datetime = parsed_date
                
                # 格式化为YYYY-MM-DD HH:MM:SS
                merged_datetime_str = merged_datetime.strftime('%Y-%m-%d %H:%M:%S')
                
                # 更新时间列
                row[time_col] = merged_datetime_str
                
                merged_count += 1
                filtered_rows.append(row)
                
            except Exception as e:
                self.logger.warning(f"行 {i+1}: 日期时间解析失败: {str(e)}")
                # 发生异常，保留该行
                filtered_rows.append(row)
                continue
        
        # 删除日期列
        updated_headers = [header for i, header in enumerate(headers) if i != date_col]
        updated_rows = []
        
        for row in filtered_rows:
            updated_row = [cell for i, cell in enumerate(row) if i != date_col]
            updated_rows.append(updated_row)
        
        self.logger.info(f"合并了 {merged_count} 行日期时间数据")
        self.logger.info(f"删除了 {deleted_count} 行{self.min_year}年之前的数据")
        self.logger.info(f"保留了 {len(filtered_rows) - merged_count} 行日期解析失败的数据")
        
        return updated_rows, updated_headers
