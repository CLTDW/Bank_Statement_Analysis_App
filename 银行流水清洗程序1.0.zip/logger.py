#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
日志记录模块
负责设置日志配置
"""

import logging
import os

def setup_logger(log_level: str = 'INFO', log_file: str = None, enable_rotation: bool = True):
    """设置日志配置
    
    Args:
        log_level: 日志级别
        log_file: 日志文件路径
        enable_rotation: 是否启用日志轮转
    """
    # 创建logger
    logger = logging.getLogger()
    logger.setLevel(getattr(logging, log_level))
    
    # 清空已有的handler
    logger.handlers.clear()
    
    # 创建formatter，添加更详细的上下文信息
    formatter = logging.Formatter(
        '%(asctime)s - %(name)s - %(levelname)s - [%(module)s.%(funcName)s:%(lineno)d] - %(message)s'
    )
    
    # 创建控制台handler，使用更简洁的格式
    console_formatter = logging.Formatter(
        '%(asctime)s - %(levelname)s - %(message)s'
    )
    console_handler = logging.StreamHandler()
    console_handler.setLevel(getattr(logging, log_level))
    console_handler.setFormatter(console_formatter)
    logger.addHandler(console_handler)
    
    # 创建文件handler
    if log_file:
        # 确保日志文件目录存在
        log_dir = os.path.dirname(log_file)
        if log_dir and not os.path.exists(log_dir):
            os.makedirs(log_dir)
        
        if enable_rotation:
            # 使用RotatingFileHandler进行日志轮转
            from logging.handlers import RotatingFileHandler
            # 自定义RotatingFileHandler的命名格式，确保备份文件保持.log扩展名
            class CustomRotatingFileHandler(RotatingFileHandler):
                def rotation_filename(self, default_name):
                    # 生成带有.log扩展名的备份文件名
                    import os
                    # 检查默认名称是否已经有.log扩展名
                    if default_name.endswith('.log'):
                        return default_name
                    # 如果没有.log扩展名，添加它
                    return default_name + '.log'
            
            file_handler = CustomRotatingFileHandler(
                log_file, 
                maxBytes=10*1024*1024,  # 10MB
                backupCount=5,  # 最多保存5个备份
                encoding='utf-8'
            )
        else:
            file_handler = logging.FileHandler(log_file, encoding='utf-8')
        
        file_handler.setLevel(getattr(logging, log_level))
        file_handler.setFormatter(formatter)
        logger.addHandler(file_handler)
    
    # 设置第三方库的日志级别
    logging.getLogger('pandas').setLevel(logging.WARNING)
    logging.getLogger('openpyxl').setLevel(logging.WARNING)
    
    # 设置模块级别的日志配置
    # 数据处理相关模块使用INFO级别
    for module in ['cleaner', 'preprocessor', 'validator', 'datetime_processor']:
        logging.getLogger(module).setLevel(getattr(logging, log_level))
    
    # 主程序使用INFO级别
    logging.getLogger('main').setLevel(getattr(logging, log_level))
