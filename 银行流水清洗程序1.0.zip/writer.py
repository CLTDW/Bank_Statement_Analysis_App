#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
数据输出模块
负责将清洗后的数据输出到Excel文件
"""

import logging
import pandas as pd
from typing import Dict, List, Any

class ExcelWriter:
    """Excel文件写入器"""
    
    def __init__(self, template_file: str, output_file: str):
        """初始化
        
        Args:
            template_file: 模板文件路径
            output_file: 输出文件路径
        """
        self.template_file = template_file
        self.output_file = output_file
        self.logger = logging.getLogger(__name__)
    

    
    def _check_excel_limit(self, data_length: int) -> bool:
        """检查数据长度是否超过Excel最大行限制
        
        Args:
            data_length: 数据行数
            
        Returns:
            bool: 是否超过限制
        """
        EXCEL_MAX_ROWS = 1048576
        return data_length > EXCEL_MAX_ROWS
    
    def _write_to_csv(self, df: pd.DataFrame, output_file: str, logger):
        """将数据写入CSV文件
        
        Args:
            df: 数据DataFrame
            output_file: 输出文件路径
            logger: 日志记录器
        """
        # 替换文件扩展名为csv
        csv_file = output_file.replace('.xlsx', '.csv').replace('.xlsm', '.csv')
        logger.info(f"数据行数超过Excel限制，改用CSV格式输出: {csv_file}")
        
        # 写入CSV文件，使用utf-8编码，处理中文
        df.to_csv(csv_file, index=False, encoding='utf-8-sig')
        logger.info(f"CSV文件写入完成，共 {len(df)} 行数据")
        return csv_file
    
    
    def convert_to_dataframe(self, data: List[List[Any]], columns: List[str]) -> pd.DataFrame:
        """转换数据为DataFrame
        
        Args:
            data: 原始数据
            columns: 列名
            
        Returns:
            pd.DataFrame: 转换后的DataFrame
        """
        # 创建数据字典列表
        data_list = []
        
        # 填充数据
        for row in data:
            # 确保行数据长度与列数一致
            row_data = {}
            # 按照列顺序填充数据
            for i, col in enumerate(columns):
                if i < len(row):
                    row_data[col] = row[i]
                else:
                    row_data[col] = None
            data_list.append(row_data)
        
        # 创建DataFrame
        df = pd.DataFrame(data_list)
        
        # 确保所有模板列都存在于DataFrame中
        for col in columns:
            if col not in df.columns:
                df[col] = None
        
        # 确保列顺序与模板一致
        df = df[columns]
        
        # 1. 重新编排序号
        for i, col in enumerate(columns):
            if '序号' in col:
                df[col] = range(1, len(df) + 1)
                break
        
        # 2. 处理需要文本格式的列
        text_columns = ['交易对方卡号', '交易对方账号', '本方账号', '本方卡号', '交易流水号', '柜员号', 'IP地址', 'MAC地址', '交易时间', '时间']
        for col in columns:
            if any(text_col in col for text_col in text_columns):
                # 确保转换为字符串，避免pandas自动转换为数值类型
                df[col] = df[col].apply(lambda x: str(x) if x is not None else '')
                df[col] = df[col].replace('None', '')
        
        # 3. 处理交易银行列
        for col in columns:
            if '交易银行' in col or '对方银行' in col:
                # 清除纯数字或纯字符的数据
                df[col] = df[col].apply(lambda x: x if isinstance(x, str) and not (x.isdigit() or x.isalpha()) else None)
        
        # 4. 处理nan字符串，视为空值
        for col in columns:
            df[col] = df[col].apply(lambda x: '' if isinstance(x, str) and x.lower() == 'nan' else x)
        
        return df
    
    def write_with_missing_info_sheet(self, cleaned_data: List[List[Any]], missing_info_data: List[List[Any]], headers: List[str], logger):
        """写入数据到Excel文件
        
        Args:
            cleaned_data: 清洗后的数据
            missing_info_data: 关键信息缺失的数据（已不再使用）
            headers: 表头信息
            logger: 日志记录器
        """
        try:
            # 读取模板文件
            logger.info(f"读取模板文件: {self.template_file}")
            
            # 尝试读取第一个sheet
            template = pd.read_excel(self.template_file)
            
            # 获取模板表头
            template_columns = list(template.columns)
            logger.info(f"模板表头包含 {len(template_columns)} 列")
            
            # 仅使用模板表头，不添加新列
            final_columns = template_columns.copy()
            
            logger.info(f"使用模板表头，共 {len(final_columns)} 列: {final_columns}")
            
            # 转换数据为DataFrame
            df = self.convert_to_dataframe(cleaned_data, final_columns)
            
            # 检查数据行数是否超过Excel限制
            if self._check_excel_limit(len(df)):
                self._write_to_csv(df, self.output_file, logger)
                return
            
            # 写入数据到输出文件，保持模板格式
            logger.info(f"写入数据到输出文件: {self.output_file}")
            
            # 先加载模板文件
            import openpyxl
            wb = openpyxl.load_workbook(self.template_file)
            ws = wb.active
            ws_name = ws.title
            
            # 清空除表头外的所有数据
            max_row = ws.max_row
            if max_row > 1:
                ws.delete_rows(2, max_row - 1)
            
            # 写入数据到工作表
            for i, (_, row) in enumerate(df.iterrows()):
                for c_idx, value in enumerate(row):
                    # Excel行和列索引从1开始，数据从第2行开始
                    cell = ws.cell(row=i + 2, column=c_idx + 1)
                    cell.value = value
            
            # 为需要文本格式的列设置单元格格式
            text_columns = ['交易对方卡号', '交易对方账号', '本方账号', '本方卡号', '交易流水号', '柜员号', 'IP地址', 'MAC地址', '交易时间', '时间']
            
            # 查找需要文本格式的列的索引
            text_col_indices = []
            for i, col in enumerate(final_columns):
                if any(text_col in col for text_col in text_columns):
                    text_col_indices.append(i)
            
            # 设置文本格式
            for col_idx in text_col_indices:
                # Excel列索引从1开始
                for row in range(2, len(df) + 2):  # 数据从第2行开始
                    cell = ws.cell(row=row, column=col_idx + 1)
                    cell.number_format = '@'  # 设置为文本格式
            
            # 保存工作簿
            wb.save(self.output_file)
            
            logger.info(f"数据写入完成，共 {len(df)} 行数据")
            
        except Exception as e:
            logger.error(f"写入Excel文件失败: {str(e)}")
            raise
