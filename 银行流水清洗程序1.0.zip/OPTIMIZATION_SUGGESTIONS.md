# 银行流水清洗程序 - 优化升级建议

## 一、核心性能瓶颈分析

### 1.1 正则表达式重复编译问题（高优先级）

**问题描述**：

当前代码中大量使用 `re.match()` 和 `re.findall()` 时，每次调用都重新编译正则表达式。这是严重的性能瓶颈。

**问题代码示例**：

```python
# validator.py 第271-272行
chinese_chars = re.findall(r'[\u4e00-\u9fa5]', clean_value)
chinese_ratio = len(chinese_chars) / len(clean_value)

# cleaner.py 第896-912行
for word in reversed(words):
    word_chinese = re.findall(r'[\u4e00-\u9fa5]+', word)
```

**优化方案**：

```python
# 在模块顶部预编译所有正则表达式
import re

# 中文字符匹配
CHINESE_PATTERN = re.compile(r'[\u4e00-\u9fa5]')
CHINESE_WORD_PATTERN = re.compile(r'[\u4e00-\u9fa5]+')

# 数字匹配
DIGIT_PATTERN = re.compile(r'\d')
NUMBER_PATTERN = re.compile(r'\d+')

# 日期时间格式
DATE_TIME_PATTERNS = {
    'date': [
        {'format': '%Y-%m-%d', 'pattern': re.compile(r'^\d{4}-\d{2}-\d{2}$')},
        # ... 其他格式
    ]
}

# 使用预编译的正则
chinese_chars = CHINESE_PATTERN.findall(clean_value)
chinese_ratio = len(chinese_chars) / len(clean_value)
```

**预期提升**：正则匹配性能提升 **5-10倍**

---

### 1.2 字符串重复拼接（中等优先级）

**问题代码示例**：

```python
# cleaner.py 第1069-1072行
for suffix in sorted(suffix_words, key=len, reverse=True):
    if string.endswith(suffix):
        string = string[:-len(suffix)]
```

**优化方案**：

```python
# 预处理：按长度降序排序，一次性处理
def remove_suffixes(string, suffixes):
    """使用最长匹配优先原则移除后缀"""
    sorted_suffixes = sorted(suffixes, key=len, reverse=True)
    for suffix in sorted_suffixes:
        if string.endswith(suffix):
            return string[:-len(suffix)], True
    return string, False
```

---

## 二、线程安全问题与并发控制优化

### 2.1 全局状态竞态条件（严重）

**问题描述**：

```python
# main.py 第102行
hw_monitor = HardwareMonitor()  # 全局单例

# main.py 第389-395行
validated_data = data_processor.process_in_parallel(
    processed_data, 
    lambda batch: validator.validate_batch(batch, main_headers),
    logger
)
```

**问题分析**：

1. `HardwareMonitor` 作为全局状态，在多线程环境下 `should_throttle()` 可能产生竞态条件
2. 日志记录器 `logger` 虽然线程安全，但频繁写入可能导致锁竞争
3. `validator.validate_batch()` 中使用 `self.logger` 存在潜在并发问题

**优化方案**：

```python
import threading
from concurrent.futures import ThreadPoolExecutor
import queue

class ThreadSafeHardwareMonitor:
    """线程安全的硬件监控器"""
    
    def __init__(self):
        self._lock = threading.RLock()
        self._last_check_time = 0
        self._cached_cpu = 0
        self._cached_memory = 0
    
    def should_throttle(self):
        with self._lock:
            # 批量检查，避免频繁调用
            current_time = time.time()
            if current_time - self._last_check_time > 0.5:  # 每0.5秒更新一次
                self._update_cache()
                self._last_check_time = current_time
            return (self._cached_cpu > self.max_cpu_percent * 0.9 or 
                    self._cached_memory > self.max_memory_percent * 0.9)
```

**建议**：在 `process_in_parallel()` 中传入专用的日志队列，避免线程间日志竞争

---

### 2.2 并行任务粒度优化

**当前问题**：

```python
# main.py 第186-254行
def process_in_parallel(self, data, process_func, logger, max_workers=None):
    # ...
    batch_size = max(500, len(data) // (max_workers * 4))
```

**问题分析**：

- 批次大小固定，未考虑数据复杂度
- 对于简单数据处理，线程开销可能大于计算时间
- 对于复杂数据（如长文本），可能导致内存不足

**优化方案**：

```python
def process_in_parallel(self, data, process_func, logger, max_workers=None):
    # 动态计算最优批次大小
    if len(data) < 1000:
        # 小数据量：串行处理，避免线程开销
        return [process_func(data)]
    
    # 中等数据量：使用较小的批次充分利用多核
    optimal_batch_size = self._calculate_optimal_batch_size(
        len(data), 
        max_workers,
        estimate_row_complexity(data[0] if data else None)
    )
    
    # 使用信号量控制并发度
    semaphore = threading.Semaphore(max_workers)
    
    def process_batch_with_semaphore(batch, batch_idx):
        with semaphore:
            return process_func(batch)
```

---

## 三、内存管理与资源优化

### 3.1 大数据处理内存峰值过高（严重）

**问题描述**：

```python
# main.py 第354-367行
preprocessor = DataPreprocessor()
processed_data = []
for sheet_name, sheet_content in sheets_data.items():
    # ...
    sheet_processed = [preprocessor.process_row(row, headers) 
                       for row in sheet_content['data']]
    processed_data.extend(sheet_processed)  # 一次性加载所有数据
```

**问题分析**：

1. 所有数据一次性加载到内存
2. `extend()` 操作会触发列表多次扩容
3. 对于超大文件可能导致内存溢出

**优化方案**：

```python
# 方案1：生成器模式（推荐）
def process_sheets_lazy(self, sheets_data):
    """惰性处理，逐sheet输出"""
    for sheet_name, sheet_content in sheets_data.items():
        for row in sheet_content['data']:
            yield preprocessor.process_row(row, headers)

# 方案2：内存映射 + 流式处理
def process_with_chunking(self, data, chunk_size=10000):
    """分块处理，控制内存使用"""
    for i in range(0, len(data), chunk_size):
        chunk = data[i:i + chunk_size]
        yield from self._process_chunk(chunk)
        # 显式释放上游引用
        del chunk
        gc.collect()

# 方案3：预分配列表容量
processed_data = []
processed_data.extend(sheet_content['data'] * 2)  # 预分配
processed_data.clear()  # 清空但不释放内存
```

---

### 3.2 对象重复创建（中等）

**问题代码示例**：

```python
# preprocessor.py 第20-23行
def __init__(self):
    from config import Config  # 每次实例化都重新导入
    self.null_placeholders = Config.NULL_PLACEHOLDERS
    self.rmb_identifiers = Config.RMB_IDENTIFIERS
```

**问题分析**：

1. 每次实例化 `DataPreprocessor` 都重新导入配置
2. 配置对象未缓存

**优化方案**：

```python
# 在模块级别创建单例配置
class _ConfigCache:
    _instance = None
    _config = None
    
    @classmethod
    def get_config(cls):
        if cls._config is None:
            from config import Config
            cls._config = Config()
        return cls._config

class DataPreprocessor:
    def __init__(self):
        config = _ConfigCache.get_config()
        self.null_placeholders = config.NULL_PLACEHOLDERS
        self.rmb_identifiers = config.RMB_IDENTIFIERS
```

---

## 四、代码质量与架构优化

### 4.1 函数职责过于单一（违反SRP）

**问题代码示例**：

```python
# cleaner.py 第593-1111行
def extract_information(self, rows, headers, file_path, object_names=None):
    """2200行代码，包含多个独立功能"""
    # 1. 提取开户行
    # 2. 提取账号
    # 3. 提取户主名称
    # 4. 验证身份证
    # 5. 匹配户主
```

**问题分析**：

- 函数超过2000行，难以维护和测试
- 包含多种无关逻辑（字符串提取、身份证验证、映射匹配）

**重构方案**：

```python
# 重构为多个专注的小函数
class InformationExtractor:
    """信息提取器（单一职责）"""
    
    def __init__(self, object_names=None):
        self.object_names = object_names or []
        self._init_patterns()
    
    def extract_bank_name(self, path_parts):
        """提取开户行信息"""
        pass
    
    def extract_account_number(self, path_parts):
        """提取账号"""
        pass
    
    def extract_account_holder(self, path_parts):
        """提取户主名称"""
        pass

class AccountHolderMatcher:
    """户主匹配器"""
    
    def build_mapping(self, rows, headers):
        """构建映射表"""
        pass
    
    def match(self, row, mapping):
        """匹配缺失字段"""
        pass
```

---

### 4.2 硬编码配置与魔法数字

**问题代码示例**：

```python
# main.py 第42-46行
if self.cpu_count <= 2:
    self.max_cpu_percent = 70
elif self.cpu_count <= 4:
    self.max_cpu_percent = 80
```

**优化方案**：

```python
# 移至配置文件
class HardwareConfig:
    CPU_THRESHOLDS = {
        (0, 2): {'max_cpu': 70, 'max_memory': 75},
        (2, 4): {'max_cpu': 80, 'max_memory': 80},
        (4, float('inf')): {'max_cpu': 90, 'max_memory': 90}
    }
    
    BATCH_SIZE_BASE = 2000
    MEMORY_FACTOR = 1000  # 每GB内存增加的批次
    MIN_BATCH_SIZE = 1000
    MAX_BATCH_SIZE = 10000
    
    @classmethod
    def get_thresholds(cls, cpu_count, memory_gb):
        for (low, high), config in cls.CPU_THRESHOLDS.items():
            if low < cpu_count <= high:
                return config
        return cls.CPU_THRESHOLDS[(4, float('inf'))]
```

---

### 4.3 异常处理不完善

**问题代码示例**：

```python
# main.py 第467-472行
except Exception as e:
    logger.error(f"处理过程中发生错误: {str(e)}")
    print(f"\n❌ 处理过程中发生错误: {str(e)}")
    import traceback
    traceback.print_exc()
    return False
```

**优化方案**：

```python
class ProcessingError(Exception):
    """数据处理异常基类"""
    def __init__(self, message, error_code, context=None):
        super().__init__(message)
        self.error_code = error_code
        self.context = context

class FileReadError(ProcessingError):
    """文件读取错误"""
    pass

class ValidationError(ProcessingError):
    """数据校验错误"""
    pass

# 使用示例
try:
    process_file(input_path)
except FileReadError as e:
    logger.error(f"文件读取失败: {e.context['file_path']}")
    # 可恢复错误：跳过当前文件继续处理
except ValidationError as e:
    logger.error(f"数据校验失败: {e}")
    # 部分失败：尝试修复或记录
except ProcessingError as e:
    logger.critical(f"致命错误: {e}")
    # 不可恢复错误：中断处理
    raise
```

---

## 五、功能增强建议

### 5.1 增量处理与断点续传

**建议实现**：

```python
class IncrementalProcessor:
    """增量处理器，支持断点续传"""
    
    def __init__(self, checkpoint_file='.checkpoint.json'):
        self.checkpoint_file = checkpoint_file
    
    def save_checkpoint(self, processed_files, last_position):
        """保存检查点"""
        checkpoint = {
            'processed_files': processed_files,
            'last_position': last_position,
            'timestamp': datetime.now().isoformat()
        }
        with open(self.checkpoint_file, 'w') as f:
            json.dump(checkpoint, f)
    
    def load_checkpoint(self):
        """加载检查点"""
        if os.path.exists(self.checkpoint_file):
            with open(self.checkpoint_file, 'r') as f:
                return json.load(f)
        return {'processed_files': [], 'last_position': 0}
```

---

### 5.2 数据质量评分系统

**建议实现**：

```python
class DataQualityScorer:
    """数据质量评分"""
    
    def __init__(self):
        self.weights = {
            'completeness': 0.3,      # 完整性权重
            'accuracy': 0.3,          # 准确性权重
            'consistency': 0.2,       # 一致性权重
            'timeliness': 0.2        # 时效性权重
        }
    
    def score_row(self, row, headers):
        """单行数据评分"""
        scores = {
            'completeness': self._check_completeness(row, headers),
            'accuracy': self._check_accuracy(row, headers),
            'consistency': self._check_consistency(row, headers),
            'timeliness': self._check_timeliness(row, headers)
        }
        return sum(scores[k] * self.weights[k] for k in scores)
    
    def generate_report(self, data, headers):
        """生成质量报告"""
        return {
            'total_rows': len(data),
            'avg_score': np.mean([self.score_row(r, headers) for r in data]),
            'quality_distribution': self._get_quality_distribution(data, headers),
            'missing_fields': self._analyze_missing_fields(data, headers)
        }
```

---

### 5.3 插件化银行处理器

**建议架构**：

```python
class BankProcessorPlugin:
    """银行处理器插件基类"""
    
    def can_process(self, file_path, headers) -> bool:
        """判断是否能处理该文件"""
        raise NotImplementedError
    
    def preprocess(self, row) -> List[Any]:
        """预处理"""
        raise NotImplementedError
    
    def validate(self, row) -> Tuple[bool, str]:
        """验证"""
        raise NotImplementedError

class ProcessorRegistry:
    """处理器注册表"""
    
    _processors = {}
    
    @classmethod
    def register(cls, bank_name, processor_class):
        cls._processors[bank_name] = processor_class
    
    @classmethod
    def get_processor(cls, file_path, headers):
        for processor in cls._processors.values():
            if processor.can_process(file_path, headers):
                return processor()
        return DefaultProcessor()

# 使用示例
@ProcessorRegistry.register('ICBC')
class ICBCProcessor(BankProcessorPlugin):
    def can_process(self, file_path, headers):
        return '工商银行' in str(headers)
```

---

## 六、测试与监控体系

### 6.1 单元测试框架

**建议添加**：

```python
import unittest
from unittest.mock import Mock, patch

class TestDataValidator(unittest.TestCase):
    """数据校验器测试"""
    
    def setUp(self):
        self.validator = DataValidator()
    
    def test_validate_account_holder_valid(self):
        """测试有效户主名称"""
        result, error = self.validator.validate_account_holder('张三')
        self.assertTrue(result)
    
    def test_validate_account_holder_invalid_length(self):
        """测试无效长度"""
        result, error = self.validator.validate_account_holder('张')
        self.assertFalse(result)
    
    def test_validate_account_number_luhn(self):
        """测试Luhn算法验证"""
        # 有效卡号
        self.assertTrue(self.validator._luhn_check('6222021234567890123'))
        # 无效卡号
        self.assertFalse(self.validator._luhn_check('6222021234567890124'))

class TestPerformance(unittest.TestCase):
    """性能测试"""
    
    def test_regex_performance(self):
        """正则表达式性能基准测试"""
        import time
        iterations = 10000
        
        # 优化前
        start = time.time()
        for _ in range(iterations):
            re.findall(r'[\u4e00-\u9fa5]', '测试数据2024')
        before = time.time() - start
        
        # 优化后（使用预编译）
        pattern = re.compile(r'[\u4e00-\u9fa5]')
        start = time.time()
        for _ in range(iterations):
            pattern.findall('测试数据2024')
        after = time.time() - start
        
        speedup = before / after
        self.assertGreater(speedup, 5, f"性能提升不足5倍，实际: {speedup:.2f}x")
```

---

### 6.2 性能监控装饰器

**建议实现**：

```python
import time
import functools
from collections import defaultdict

class PerformanceMonitor:
    """性能监控器"""
    
    _metrics = defaultdict(list)
    
    @classmethod
    def monitor(cls, name=None):
        """性能监控装饰器"""
        def decorator(func):
            @functools.wraps(func)
            def wrapper(*args, **kwargs):
                start = time.perf_counter()
                result = func(*args, **kwargs)
                elapsed = time.perf_counter() - start
                
                metric_name = name or f"{func.__module__}.{func.__name__}"
                cls._metrics[metric_name].append(elapsed)
                
                # 慢操作警告
                if elapsed > 1.0:
                    logger.warning(f"慢操作检测: {metric_name} 耗时 {elapsed:.2f}s")
                
                return result
            return wrapper
        return decorator
    
    @classmethod
    def get_report(cls):
        """生成性能报告"""
        report = {}
        for name, times in cls._metrics.items():
            report[name] = {
                'count': len(times),
                'total': sum(times),
                'avg': sum(times) / len(times),
                'min': min(times),
                'max': max(times),
                'p95': sorted(times)[int(len(times) * 0.95)]
            }
        return report

# 使用示例
@PerformanceMonitor.monitor('validate_batch')
def validate_batch(batch, headers):
    # ... 原有逻辑
    pass
```

---

## 七、部署与运维优化

### 7.1 配置外部化

**建议架构**：

```python
# config.yaml
hardware:
  cpu_thresholds:
    2: {max_cpu: 70, max_memory: 75}
    4: {max_cpu: 80, max_memory: 80}
    inf: {max_cpu: 90, max_memory: 90}
  batch_size_base: 2000
  memory_factor: 1000

processing:
  min_batch_size: 1000
  max_batch_size: 10000
  checkpoint_enabled: true

logging:
  level: INFO
  rotation:
    max_bytes: 10485760  # 10MB
    backup_count: 5
```

**加载配置**：

```python
import yaml
from pathlib import Path

def load_config(config_path='config.yaml'):
    """加载外部配置"""
    config_file = Path(config_path)
    if config_file.exists():
        with open(config_file) as f:
            return yaml.safe_load(f)
    return get_default_config()
```

---

### 7.2 健康检查接口

**建议实现**：

```python
from flask import Flask, jsonify
import psutil

app = Flask(__name__)

@app.route('/health')
def health_check():
    """健康检查"""
    return jsonify({
        'status': 'healthy',
        'cpu': psutil.cpu_percent(),
        'memory': psutil.virtual_memory().percent,
        'disk': psutil.disk_usage('/').percent
    })

@app.route('/metrics')
def metrics():
    """性能指标"""
    return jsonify({
        'performance': PerformanceMonitor.get_report(),
        'config': get_current_config()
    })
```

---

## 八、优先级实施计划

### Phase 1：性能优化（1-2周）

| 优先级 | 任务 | 预期效果 |
|--------|------|----------|
| P0 | 正则表达式预编译 | 性能提升5-10倍 |
| P0 | 内存优化（生成器/分块） | 内存使用降低50% |
| P1 | 字符串拼接优化 | 处理速度提升20% |

### Phase 2：稳定性提升（2-3周）

| 优先级 | 任务 | 预期效果 |
|--------|------|----------|
| P0 | 线程安全改造 | 并发处理稳定性 |
| P1 | 异常处理完善 | 错误定位效率 |
| P1 | 断点续传功能 | 大文件处理可靠性 |

### Phase 3：可维护性（3-4周）

| 优先级 | 任务 | 预期效果 |
|--------|------|----------|
| P1 | 代码重构（extract_information） | 代码可读性提升 |
| P2 | 单元测试覆盖 | 测试覆盖率>80% |
| P2 | 配置外部化 | 部署灵活性 |

### Phase 4：功能增强（持续迭代）

| 优先级 | 任务 | 预期效果 |
|--------|------|----------|
| P2 | 插件化银行处理器 | 扩展性 |
| P2 | 数据质量评分 | 数据可信度 |
| P3 | Web监控界面 | 运维便利性 |

---

## 九、总结

本项目的优化应遵循以下原则：

1. **性能优先**：正则预编译和内存优化是首要任务
2. **稳定为本**：线程安全是并发处理的基础
3. **渐进式重构**：避免大规模重写导致的风险
4. **数据驱动**：通过性能监控量化优化效果

建议从 Phase 1 的 P0 任务开始实施，这些改动风险低、收益高。
