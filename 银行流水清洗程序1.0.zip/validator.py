#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
校验规则模块
负责数据的校验工作，包括字段完整性校验、字段数据结构校验等
"""

import logging
import re
from typing import Dict, List, Any, Tuple

class DataValidator:
    """数据校验器"""
    
    def __init__(self):
        """初始化"""
        self.logger = logging.getLogger(__name__)
        # 必需字段组合（从配置文件导入）
        from config import Config
        self.required_field_combinations = Config.REQUIRED_FIELD_COMBINATIONS
        self.valid_headers = Config.VALID_HEADERS
        # 百家姓（用于校验户主名称）
        self.surnames = Config.SURNAMES
    
    def validate(self, sheets_data: Dict[str, Dict[str, Any]]) -> Dict[str, Dict[str, Any]]:
        """校验所有sheet的数据
        
        Args:
            sheets_data: 预处理后的数据
            
        Returns:
            Dict: 校验后的数据，包含异常标记
        """
        validated_data = {}
        
        for sheet_name, sheet_content in sheets_data.items():
            self.logger.info(f"校验sheet: {sheet_name}")
            
            # 1. 字段完整性校验
            is_valid_sheet, missing_fields = self.validate_field_completeness(
                sheet_content['headers']
            )
            
            if not is_valid_sheet:
                self.logger.warning(f"Sheet '{sheet_name}' 缺少必需字段: {missing_fields}")
                validated_data[sheet_name] = {
                    'headers': sheet_content['headers'],
                    'data': [],
                    'errors': [f"关键字段缺失: {missing_fields}"]
                }
                continue
            
            # 2. 字段数据结构校验
            validated_rows = []
            errors = []
            
            # 找出关键字段的索引
            key_field_indices = {}
            key_fields = ['交易日期', '交易时间', '交易金额', '金额', '借方金额', '贷方金额']
            
            for i, header in enumerate(sheet_content['headers']):
                for key_field in key_fields:
                    if key_field in header:
                        key_field_indices[key_field] = i
                        break
            
            for i, row in enumerate(sheet_content['data']):
                row_errors = []
                validated_row = []
                
                for j, cell in enumerate(row):
                    header = sheet_content['headers'][j] if j < len(sheet_content['headers']) else ''
                    validation_result, error_msg = self.validate_field(header, cell)
                    validated_row.append(cell if validation_result else None)
                    if error_msg:
                        row_errors.append(f"第{j+1}列 '{header}': {error_msg}")
                
                # 3. 增强的数据完整性检查
                # 检查关键字段是否有值
                missing_key_values = []
                
                # 检查交易日期/时间
                if '交易日期' in key_field_indices:
                    date_idx = key_field_indices['交易日期']
                    if date_idx < len(row) and (row[date_idx] is None or 
                                               (isinstance(row[date_idx], str) and not row[date_idx].strip())):
                        missing_key_values.append('交易日期')
                
                # 检查交易时间（如果有）
                if '交易时间' in key_field_indices:
                    time_idx = key_field_indices['交易时间']
                    if time_idx < len(row) and (row[time_idx] is None or 
                                               (isinstance(row[time_idx], str) and not row[time_idx].strip())):
                        missing_key_values.append('交易时间')
                
                # 检查金额字段
                has_amount = False
                if '交易金额' in key_field_indices:
                    amount_idx = key_field_indices['交易金额']
                    if amount_idx < len(row) and row[amount_idx] is not None:
                        if isinstance(row[amount_idx], str):
                            if row[amount_idx].strip():
                                has_amount = True
                        else:
                            has_amount = True
                elif '金额' in key_field_indices:
                    amount_idx = key_field_indices['金额']
                    if amount_idx < len(row) and row[amount_idx] is not None:
                        if isinstance(row[amount_idx], str):
                            if row[amount_idx].strip():
                                has_amount = True
                        else:
                            has_amount = True
                
                # 检查借方/贷方金额
                has_debit_credit = False
                if '借方金额' in key_field_indices and '贷方金额' in key_field_indices:
                    debit_idx = key_field_indices['借方金额']
                    credit_idx = key_field_indices['贷方金额']
                    
                    debit_valid = False
                    if debit_idx < len(row) and row[debit_idx] is not None:
                        if isinstance(row[debit_idx], str):
                            if row[debit_idx].strip():
                                debit_valid = True
                        else:
                            debit_valid = True
                    
                    credit_valid = False
                    if credit_idx < len(row) and row[credit_idx] is not None:
                        if isinstance(row[credit_idx], str):
                            if row[credit_idx].strip():
                                credit_valid = True
                        else:
                            credit_valid = True
                    
                    has_debit_credit = debit_valid or credit_valid
                
                # 如果既没有交易金额，也没有借方/贷方金额，则标记为缺失
                if not has_amount and not has_debit_credit:
                    missing_key_values.append('交易金额或借贷金额')
                
                if missing_key_values:
                    row_errors.append(f"缺失关键字段值: {', '.join(missing_key_values)}")
                
                if row_errors:
                    errors.append(f"第{i+1}行: {'; '.join(row_errors)}")
                validated_rows.append(validated_row)
            
            validated_data[sheet_name] = {
                'headers': sheet_content['headers'],
                'data': validated_rows,
                'errors': errors
            }
            
            self.logger.info(f"Sheet '{sheet_name}' 校验完成，发现 {len(errors)} 个错误")
        
        return validated_data
    
    def validate_field_completeness(self, headers: List[str]) -> Tuple[bool, List[str]]:
        """校验字段完整性
        
        Args:
            headers: 表头
            
        Returns:
            Tuple[bool, List[str]]: (是否有效, 缺失的字段组合信息)
        """
        # 检查是否满足任一必需字段组合
        for i, combination in enumerate(self.required_field_combinations):
            # 检查组合中的每个字段组是否都有匹配
            combination_valid = True
            
            for field_group in combination:
                field_found = False
                for header in headers:
                    for field in field_group:
                        if field in header:
                            field_found = True
                            break
                    if field_found:
                        break
                
                if not field_found:
                    combination_valid = False
                    break
            
            if combination_valid:
                return True, []
        
        # 所有组合都不满足
        return False, ["未满足任何必需字段组合"]
    
    def validate_field(self, header: str, value: Any) -> Tuple[bool, str]:
        """校验单个字段
        
        Args:
            header: 字段名称
            value: 字段值
            
        Returns:
            Tuple[bool, str]: (是否有效, 错误信息)
        """
        try:
            # 处理空值
            if value is None:
                return True, ""
            
            # 根据字段名称选择校验规则
            if '户主名称' in header:
                result, error = self.validate_account_holder(value)
                if not result:
                    self.logger.warning(f"字段 '{header}' 校验失败: {error}, 值: {value}")
                return result, error
            elif '本方账户开户行' in header or '开户行' in header:
                result, error = self.validate_bank(value)
                if not result:
                    self.logger.warning(f"字段 '{header}' 校验失败: {error}, 值: {value}")
                return result, error
            elif '银行卡类别' in header or '卡类别' in header:
                result, error = self.validate_card_type(value)
                if not result:
                    self.logger.warning(f"字段 '{header}' 校验失败: {error}, 值: {value}")
                return result, error
            elif '本方账号' in header or '本方卡号' in header or '账号' in header or '卡号' in header:
                result, error = self.validate_account_number(value)
                if not result:
                    self.logger.warning(f"字段 '{header}' 校验失败: {error}, 值: {value}")
                return result, error
            elif '交易对方账号' in header or '交易对方卡号' in header:
                result, error = self.validate_account_number(value)
                if not result:
                    self.logger.warning(f"字段 '{header}' 校验失败: {error}, 值: {value}")
                return result, error
            elif '交易日期' in header or '交易时间' in header or '日期' in header or '时间' in header:
                result, error = self.validate_date_time(value)
                if not result:
                    self.logger.warning(f"字段 '{header}' 校验失败: {error}, 值: {value}")
                return result, error
            elif '交易金额' in header or '金额' in header or '借方金额' in header or '贷方金额' in header:
                result, error = self.validate_amount(value)
                if not result:
                    self.logger.warning(f"字段 '{header}' 校验失败: {error}, 值: {value}")
                return result, error
            elif '交易摘要' in header or '交易备注' in header or '摘要' in header or '备注' in header:
                result, error = self.validate_description(value)
                if not result:
                    self.logger.warning(f"字段 '{header}' 校验失败: {error}, 值: {value}")
                return result, error
            
            # 默认返回有效
            return True, ""
        except Exception as e:
            self.logger.error(f"字段 '{header}' 校验过程出错: {str(e)}, 值: {value}")
            # 校验过程出错时，返回False和错误信息
            return False, f"校验过程出错: {str(e)}"
    
    def validate_account_holder(self, value: Any) -> Tuple[bool, str]:
        """校验户主名称
        
        Args:
            value: 户主名称
            
        Returns:
            Tuple[bool, str]: (是否有效, 错误信息)
        """
        if not isinstance(value, str):
            return False, "必须为字符串类型"
        
        # 清理空格和特殊符号
        clean_value = re.sub(r'\s+|[^\u4e00-\u9fa5a-zA-Z0-9]', '', value)
        
        # 长度规则
        if len(clean_value) < 2 or len(clean_value) > 30:
            return False, "长度必须在2-30个字符之间"
        
        # 不得为纯数字或纯符号
        if re.match(r'^\d+$', clean_value) or re.match(r'^[^\u4e00-\u9fa5a-zA-Z0-9]+$', value):
            return False, "不得为纯数字或纯符号"
        
        # 汉字占比计算
        chinese_chars = re.findall(r'[\u4e00-\u9fa5]', clean_value)
        chinese_ratio = len(chinese_chars) / len(clean_value) if len(clean_value) > 0 else 0
        
        if chinese_ratio < 0.6:
            return False, "汉字占比必须≥60%"
        
        # 检查是否为人名或公司名
        is_person_name = False
        is_company_name = False
        
        # 检查是否为公司名
        company_keywords = ['公司', '有限责任公司', '股份公司', '集团', '有限公司', '企业', '商行', '银行', '机构', '组织']
        for keyword in company_keywords:
            if keyword in value:
                is_company_name = True
                break
        
        # 如果不是公司名，检查是否为人名
        if not is_company_name:
            # 使用config.py中的SURNAMES
            # 检查是否以常见姓氏开头
            for surname in self.surnames:
                if value.startswith(surname) and len(value) >= 2:
                    is_person_name = True
                    break
            
            # 检查是否为双字姓氏
            double_surnames = {'欧阳', '上官', '司马', '诸葛', '司徒', '司空', '公孙', '东方', '皇甫', '尉迟', '公羊', '澹台', '申屠', '太叔', '轩辕', '令狐', '钟离', '宇文', '长孙', '慕容'}
            for surname in double_surnames:
                if value.startswith(surname) and len(value) >= 3:
                    is_person_name = True
                    break
        
        # 只在确实可疑时记录警告
        if not is_person_name and not is_company_name:
            # 进一步检查：如果包含常见人名特征词，也视为有效
            person_indicators = ['先生', '女士', '小姐', '同志', '师傅', '老师', '医生', '教授']
            for indicator in person_indicators:
                if indicator in value:
                    is_person_name = True
                    break
            
            # 仍然可疑，才记录警告
            if not is_person_name:
                self.logger.warning(f"可疑户主名称: {value}")
        
        return True, ""
    
    def validate_bank(self, value: Any) -> Tuple[bool, str]:
        """校验开户行
        
        Args:
            value: 开户行
            
        Returns:
            Tuple[bool, str]: (是否有效, 错误信息)
        """
        if not isinstance(value, str):
            return False, "必须为字符串类型"
        
        # 清理空格和特殊符号
        clean_value = re.sub(r'\s+|[^\u4e00-\u9fa5a-zA-Z0-9]', '', value)
        
        # 长度规则
        if len(clean_value) < 2 or len(clean_value) > 30:
            return False, "长度必须在2-30个字符之间"
        
        # 不得为纯数字或纯符号
        if re.match(r'^\d+$', clean_value) or re.match(r'^[^\u4e00-\u9fa5a-zA-Z0-9]+$', value):
            return False, "不得为纯数字或纯符号"
        
        # 汉字占比计算
        chinese_chars = re.findall(r'[\u4e00-\u9fa5]', clean_value)
        chinese_ratio = len(chinese_chars) / len(clean_value) if len(clean_value) > 0 else 0
        
        if chinese_ratio < 0.9:
            return False, "汉字占比必须≥90%"
        
        # 必须包含银行相关关键词
        bank_keywords = ['银行', '支行', '分行', '营业部', '分理处', '行', '中心', '信用社', '总行', '农商行', '财付通', '支付宝']
        has_keyword = any(keyword in value for keyword in bank_keywords)
        
        if not has_keyword:
            return False, "必须包含银行相关关键词"
        
        return True, ""
    
    def validate_card_type(self, value: Any) -> Tuple[bool, str]:
        """校验银行卡类别
        
        Args:
            value: 银行卡类别
            
        Returns:
            Tuple[bool, str]: (是否有效, 错误信息)
        """
        if not isinstance(value, str):
            return False, "必须为字符串类型"
        
        # 清理空格
        clean_value = value.strip()
        
        # 长度规则
        if len(clean_value) < 2 or len(clean_value) > 15:
            return False, "长度必须在2-15个字符之间"
        
        # 不得为纯数字或纯符号
        if re.match(r'^\d+$', clean_value) or re.match(r'^[^\u4e00-\u9fa5a-zA-Z]+$', clean_value):
            return False, "不得为纯数字或纯符号"
        
        # 不得包含数字
        if re.search(r'\d', clean_value):
            return False, "不得包含数字"
        
        return True, ""
    
    def validate_account_number(self, value: Any) -> Tuple[bool, str]:
        """校验账号/卡号
        
        Args:
            value: 账号/卡号
            
        Returns:
            Tuple[bool, str]: (是否有效, 错误信息)
        """
        if not isinstance(value, str):
            value = str(value)
        
        # 清理空格
        clean_value = re.sub(r'\s+', '', value)
        
        # 长度规则（银行卡号通常为16-19位，账号可能更长）
        if len(clean_value) < 8 or len(clean_value) > 30:
            return False, "长度必须在8-30位之间"
        
        # 计算数字占比
        digits = re.findall(r'\d', clean_value)
        digit_ratio = len(digits) / len(clean_value) if len(clean_value) > 0 else 0
        
        if digit_ratio < 0.75:
            return False, "数字占比必须≥75%"
        
        return True, ""
    
    def validate_date_time(self, value: Any) -> Tuple[bool, str]:
        """校验日期时间
        
        Args:
            value: 日期时间
            
        Returns:
            Tuple[bool, str]: (是否有效, 错误信息)
        """
        # 日期时间格式多样，这里做更详细的检查
        if value is None:
            return False, "不能为空"
        
        # 尝试解析日期时间
        if isinstance(value, str):
            # 清理空格
            value = value.strip()
            
            # 尝试不同的日期格式
            date_formats = [
                '%Y-%m-%d', '%Y/%m/%d', '%Y.%m.%d',
                '%d-%m-%Y', '%d/%m/%Y', '%d.%m.%Y',
                '%Y年%m月%d日', '%Y年%m月%d',
                '%Y%m%d'
            ]
            
            time_formats = [
                '%H:%M:%S', '%H:%M','%H%M','%H%M%S',
                '%H时%M分%S秒', '%H时%M分'
            ]
            
            datetime_formats = [
                '%Y-%m-%d %H:%M:%S', '%Y/%m/%d %H:%M:%S', '%Y-%m-%d %H:%M', '%Y/%m/%d %H:%M',
                '%Y-%m-%dT%H:%M:%S', '%Y%m%d%H%M', '%Y年%m月%d日%H时%M分%S秒', '%Y年%m月%d日%H时%M分',
                '%Y%m%d%H%M%S'
            ]
            
            # 尝试解析日期时间组合格式
            for fmt in datetime_formats:
                try:
                    import datetime
                    datetime.datetime.strptime(value, fmt)
                    return True, ""
                except ValueError:
                    pass
            
            # 尝试解析日期格式
            for fmt in date_formats:
                try:
                    import datetime
                    datetime.datetime.strptime(value, fmt)
                    return True, ""
                except ValueError:
                    pass
            
            # 尝试解析时间格式
            for fmt in time_formats:
                try:
                    import datetime
                    datetime.datetime.strptime(value, fmt)
                    return True, ""
                except ValueError:
                    pass
            
            # 如果所有格式都解析失败
            return False, "日期时间格式无效"
        
        # 如果是数字，可能是Excel序列号或时间戳
        elif isinstance(value, (int, float)):
            try:
                # 检查是否为14位数字时间戳
                value_str = str(int(value))
                if len(value_str) == 14 and value_str.isdigit():
                    import datetime
                    # 按年月日时分秒格式解析
                    dt = datetime.datetime.strptime(value_str, '%Y%m%d%H%M%S')
                    return True, ""
                
                # 否则尝试作为Excel序列号处理
                import datetime
                # Excel序列号从1900年1月1日开始
                dt = datetime.datetime(1899, 12, 30) + datetime.timedelta(days=float(value))
                return True, ""
            except:
                return False, "日期时间格式无效"
        
        return True, ""
    
    def validate_amount(self, value: Any) -> Tuple[bool, str]:
        """校验金额
        
        Args:
            value: 金额
            
        Returns:
            Tuple[bool, str]: (是否有效, 错误信息)
        """
        if value is None:
            return False, "不能为空"
        
        # 尝试转换为数字
        try:
            amount = float(value)
        except (ValueError, TypeError):
            return False, "必须为数字"
        
        return True, ""
    
    def validate_description(self, value: Any) -> Tuple[bool, str]:
        """校验交易摘要/备注
        
        Args:
            value: 交易摘要/备注
            
        Returns:
            Tuple[bool, str]: (是否有效, 错误信息)
        """
        if isinstance(value, str):
            # 长度限制
            if len(value) > 50:
                return False, "长度不能超过50个字符"
        
        return True, ""
    
    def validate_batch(self, batch: List[List[Any]], headers: List[str]) -> List[List[Any]]:
        """批量校验数据
        
        Args:
            batch: 批量数据
            headers: 表头
            
        Returns:
            List: 校验后的数据，无效行返回None
        """
        validated_batch = []
        
        for row_idx, row in enumerate(batch):
            try:
                validated_row = []
                row_valid = True
                
                for j, cell in enumerate(row):
                    header = headers[j] if j < len(headers) else ''
                    
                    # 跳过空值检查，只校验非空值
                    if cell is None:
                        validated_row.append(None)
                        continue
                    
                    try:
                        validation_result, error_msg = self.validate_field(header, cell)
                        
                        if not validation_result:
                            # 只对关键字段严格校验
                            key_fields = ['交易日期', '交易时间', '交易金额', '金额', '借方金额', '贷方金额']
                            is_key_field = any(key_field in header for key_field in key_fields)
                            
                            # 如果是关键字段无效，则整行无效
                            if is_key_field:
                                row_valid = False
                                self.logger.warning(f"批量校验: 行 {row_idx+1} 关键字段 '{header}' 无效: {error_msg}")
                                break
                            # 如果是非关键字段无效，跳过该字段
                            else:
                                validated_row.append(None)
                                self.logger.debug(f"批量校验: 行 {row_idx+1} 非关键字段 '{header}' 无效: {error_msg}")
                        else:
                            validated_row.append(cell)
                    except Exception as e:
                        self.logger.error(f"批量校验: 行 {row_idx+1} 字段 '{header}' 校验出错: {str(e)}")
                        # 字段校验出错时，视情况处理
                        key_fields = ['交易日期', '交易时间', '交易金额', '金额', '借方金额', '贷方金额']
                        is_key_field = any(key_field in header for key_field in key_fields)
                        if is_key_field:
                            row_valid = False
                            break
                        else:
                            validated_row.append(None)
                
                # 如果整行有效，添加到结果中；否则添加None表示无效行
                if row_valid:
                    validated_batch.append(validated_row)
                else:
                    validated_batch.append(None)
            except Exception as e:
                self.logger.error(f"批量校验: 行 {row_idx+1} 处理出错: {str(e)}")
                validated_batch.append(None)
        
        return validated_batch
